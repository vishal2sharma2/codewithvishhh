# **App Name**: ChatterBox Rooms

## Core Features:

- Room Creation/Joining: Allow users to enter a room name or generate a new one upon visiting the root URL.
- Room Redirection: Redirect users to a dedicated room page (e.g., /room/:roomName) once they've selected or created a room.
- Real-time Chat: Enable real-time messaging within the selected room using Socket.IO, ensuring messages are only visible to users in the same room.
- Join/Leave Notifications: Display notifications to users within a room when someone joins or leaves.
- AI-Powered Chat Suggestions: AI tool that provides intelligent message suggestions to guide user interaction in the chat.

## Style Guidelines:

- Primary color: A calm blue (#3498db) for headers and main elements to promote a sense of tranquility.
- Secondary color: A neutral gray (#ecf0f1) for backgrounds to ensure readability and minimize distractions.
- Accent: A vibrant green (#2ecc71) for new message notifications and active states, indicating activity.
- Clear and modern fonts for all text elements.
- Use simple, outlined icons for room actions and user status.
- Clean and intuitive layout with clear separation of chat rooms and message areas.
- Subtle transitions and animations for new messages and user joins/leaves.