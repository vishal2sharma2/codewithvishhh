
import type { NextApiRequest, NextApiResponse } from 'next';
import type { Message, ReportedMessageInfo } from '@/types';
import { reportedMessagesStore } from './socket'; // Import the shared store
import { v4 as uuidv4 } from 'uuid';

interface ReportPayload {
  message: Message;
  roomName: string;
  reporterSocketId: string | null; // Can be null if user is not fully identified or it's a system report
}

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { message, roomName, reporterSocketId } = req.body as ReportPayload;

    if (!message || !message.id || !roomName) {
      return res.status(400).json({ error: 'Missing required report data: message, message.id, or roomName.' });
    }

    const newReport: ReportedMessageInfo = {
      reportId: uuidv4(),
      message: message,
      roomName: roomName,
      reporterSocketId: reporterSocketId || null,
      reportedAt: new Date().toISOString(),
    };

    reportedMessagesStore.push(newReport);
    console.log(`[API /report-message] New report stored. Total reports: ${reportedMessagesStore.length}. Reported message ID: ${message.id} in room ${roomName}`);

    return res.status(200).json({ success: true, message: 'Message reported successfully.' });
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
