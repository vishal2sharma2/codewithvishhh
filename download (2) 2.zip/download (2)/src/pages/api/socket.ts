
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { NextApiRequest, NextApiResponse } from 'next';
import { Server as IOServer, Socket as ServerSocket } from 'socket.io';
import type { UserProfile, JoinRoomPayload, Message, RoomData, RetentionPolicy, RoomMode, ReportedMessageInfo, RoomSettingsUpdateNotification } from '@/types'; // Changed User to UserProfile
import { v4 as uuidv4 } from 'uuid';


interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

interface AppData {
  activeRooms: Map<string, RoomData>;
  reportedMessages: ReportedMessageInfo[];
}

interface EnhancedIOServer extends IOServer {
  appData?: AppData;
}

const defaultPrivacyPolicyHTML = `
          <p class="text-muted-foreground text-center mb-6">
            Last updated: July 26, 2024
          </p>
          <h2>1. Introduction</h2><p>Your privacy is important to us...</p>
          <h2>2. Information We Collect</h2><p>We only ask for personal information...</p>
          <p>Information we collect may include:</p>
          <ul><li><strong>Log data:</strong> ...</li><li><strong>Device data:</strong> ...</li><li><strong>Personal information:</strong> ...<ul><li>Display Name ...</li><li>Chat messages ...</li></ul></li></ul>
          <h2>3. How We Use Your Information</h2><p>We may use the information...</p>
          <ul><li>Provide, operate, and maintain...</li><li>Improve, personalize, and expand...</li><li>Understand and analyze...</li><li>Develop new products, services...</li><li>Communicate with you...</li><li>Find and prevent fraud.</li></ul>
          <h2>4. Data Retention</h2><p>We only retain collected information...</p>
          <h2>5. Sharing Your Personal Information</h2><p>We don’t share any personally identifying information...</p>
          <h2>6. Cookies</h2><p>Our website may use “cookies”...</p>
          <h2>7. Your Rights</h2><p>You are free to refuse our request...</p>
          <h2>8. Links to Other Sites</h2><p>Our website may link to external sites...</p>
          <h2>9. Changes to Our Privacy Policy</h2><p>We reserve the right to modify...</p>
          <h2>10. Contact Us</h2><p>If you have any questions... [Your Contact Email or Link to Contact Form]</p>
          <p class="mt-6 text-center text-destructive font-semibold">[THIS IS A TEMPLATE. PLEASE REPLACE WITH YOUR OWN PRIVACY POLICY. CONSULT A LEGAL PROFESSIONAL.]</p>
`;

const defaultTermsAndConditionsHTML = `
          <p class="text-muted-foreground text-center mb-6">
            Last updated: July 26, 2024
          </p>
          <h2>1. Introduction</h2><p>Welcome to ChatterBox Rooms! ...</p>
          <h2>2. Intellectual Property Rights</h2><p>Other than the content you own...</p>
          <h2>3. Restrictions</h2><p>You are specifically restricted from...</p><ul><li>Publishing any Website material...</li><li>Selling, sublicensing...</li><li>Publicly performing...</li><li>Using this Website in any way that is or may be damaging...</li><li>Using this Website in any way that impacts user access...</li><li>Using this Website contrary to applicable laws...</li><li>Engaging in any data mining...</li><li>Using this Website to engage in any advertising...</li></ul>
          <p>Certain areas of this Website are restricted...</p>
          <h2>4. Your Content</h2><p>In these Website Standard Terms...</p><p>Your Content must be your own...</p>
          <h2>5. No warranties</h2><p>This Website is provided “as is,”...</p>
          <h2>6. Limitation of liability</h2><p>In no event shall ChatterBox Rooms...</p>
          <h2>7. Indemnification</h2><p>You hereby indemnify to the fullest extent ChatterBox Rooms...</p>
          <h2>8. Severability</h2><p>If any provision of these Terms is found to be invalid...</p>
          <h2>9. Variation of Terms</h2><p>ChatterBox Rooms is permitted to revise...</p>
          <h2>10. Assignment</h2><p>The ChatterBox Rooms is allowed to assign...</p>
          <h2>11. Entire Agreement</h2><p>These Terms constitute the entire agreement...</p>
          <h2>12. Governing Law & Jurisdiction</h2><p>These Terms will be governed by and interpreted...</p>
          <p class="mt-6 text-center text-destructive font-semibold">[THIS IS A TEMPLATE. PLEASE REPLACE WITH YOUR OWN TERMS AND CONDITIONS. CONSULT A LEGAL PROFESSIONAL.]</p>
`;

export let globalSettings = {
  websiteName: "ChatterBox Rooms",
  homepageHeroTitle: "Welcome to ChatterBox Rooms",
  tagline: "Connect, collaborate, and chat in real-time. Your display name will be set when you join a room.",
  footerText: `© ${new Date().getFullYear()} ChatterBox Rooms. All rights reserved.`,
  homepageFeatureSectionTitle: "Why ChatterBox?",
  homepageBannerUrl: "https://placehold.co/800x300.png",
  homepageBannerAltText: "Chat application banner with diverse people collaborating",
  feature1Title: "Instant Rooms",
  feature1Description: "Generate unique room names or create your own in seconds. No sign-ups, just chat.",
  feature2Title: "AI-Powered Suggestions",
  feature2Description: "Never run out of things to say with intelligent reply suggestions to keep the conversation flowing.",
  feature3Title: "Group Chat Made Easy",
  feature3Description: "Simple and intuitive interface for group conversations.",
  termsAndConditionsHTML: defaultTermsAndConditionsHTML,
  privacyPolicyHTML: defaultPrivacyPolicyHTML,
  instagramUrl: "https://instagram.com",
  linkedinUrl: "https://linkedin.com",
  youtubeUrl: "https://youtube.com",
};

export let reportedMessagesStore: ReportedMessageInfo[] = [];


const MESSAGE_CLEANUP_INTERVAL = 60 * 1000;
const DEFAULT_MAX_USERS_SERVER = 10;

function getRetentionMilliseconds(policy: RetentionPolicy | null | undefined): number {
  if (!policy || policy === 'none') return Infinity;
  const unit = policy.slice(-1);
  const value = parseInt(policy.slice(0, -1));
  if (isNaN(value)) return Infinity;

  switch (unit) {
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    default: return Infinity;
  }
}

function cleanupExpiredMessages(ioInstance: EnhancedIOServer | undefined) {
  if (!ioInstance || !ioInstance.appData || !ioInstance.appData.activeRooms) {
    console.warn('[Socket.IO Cleanup] IO instance or appData.activeRooms not available. Skipping cleanup.');
    return;
  }
  const activeRooms = ioInstance.appData.activeRooms;
  const now = Date.now();
  activeRooms.forEach((roomData, roomName) => {
    if (roomData.retentionPolicy && roomData.retentionPolicy !== 'none') {
      const retentionMillis = getRetentionMilliseconds(roomData.retentionPolicy);
      if (retentionMillis === Infinity) return;

      const cutoffTime = now - retentionMillis;
      const initialMsgCount = roomData.messages.length;
      roomData.messages = roomData.messages.filter(
        (msg) => new Date(msg.timestamp).getTime() >= cutoffTime
      );
      if (roomData.messages.length < initialMsgCount) {
         console.log(`[Socket.IO] Cleaned ${initialMsgCount - roomData.messages.length} messages from room '${roomName}'`);
      }
    }
  });
}


export default function SocketHandler(
  _req: NextApiRequest,
  res: NextApiResponseWithSocket
) {
  console.log('[SocketHandler] API endpoint hit.');
  if (res.socket.server.io) {
    console.log('[SocketHandler] Socket.IO server already running on this HTTP server instance.');
    const ioInstance = res.socket.server.io;
    if (!ioInstance.appData) {
        ioInstance.appData = { 
            activeRooms: new Map<string, RoomData>(), 
            reportedMessages: reportedMessagesStore 
        };
        console.log('[SocketHandler] io.appData fully initialized on pre-existing io instance.');
    }
    if (!ioInstance.appData.activeRooms) {
        ioInstance.appData.activeRooms = new Map<string, RoomData>();
        console.log('[SocketHandler] io.appData.activeRooms initialized on existing appData (was missing).');
    }
    if (!ioInstance.appData.reportedMessages || ioInstance.appData.reportedMessages !== reportedMessagesStore) {
         ioInstance.appData.reportedMessages = reportedMessagesStore;
         console.log('[SocketHandler] io.appData.reportedMessages (re)initialized to use shared store on existing appData.');
    }

  } else {
    console.log('[SocketHandler] Initializing new Socket.IO server...');
    const io = new IOServer(res.socket.server, {
      path: '/api/socket_io',
      addTrailingSlash: false,
      cors: { origin: "*", methods: ["GET", "POST"] },
      maxHttpBufferSize: 1e7 
    }) as EnhancedIOServer;

    io.appData = {
      activeRooms: new Map<string, RoomData>(),
      reportedMessages: reportedMessagesStore, 
    };
    console.log('[SocketHandler] io.appData.activeRooms and .reportedMessages initialized for new io instance.');
    
    res.socket.server.io = io;

    if (typeof (global as any).messageCleanupInterval === 'undefined') {
      (global as any).messageCleanupInterval = setInterval(() => cleanupExpiredMessages(io), MESSAGE_CLEANUP_INTERVAL);
      console.log('[SocketHandler] Message cleanup interval started.');
    }

    io.on('connection', (socket: ServerSocket) => {
      console.log(`[Socket.IO] User connected: ${socket.id}. Total connections: ${io.engine.clientsCount}`);
      const currentActiveRooms = io.appData!.activeRooms;

      socket.on('join-room', ({ roomName, userName, userAge, userCity, password, retentionPolicy = 'none', roomMode = 'public', maxUsers }: JoinRoomPayload) => {
        console.log(`[Socket.IO] 'join-room' event received for room '${roomName}' by user '${userName}' (ID: ${socket.id}, Age: ${userAge}, City: ${userCity}) with maxUsers: ${maxUsers}, retention: ${retentionPolicy}, mode: ${roomMode}`);
        let roomData = currentActiveRooms.get(roomName);
        let isNewRoom = false;
        const effectiveMaxUsers = (typeof maxUsers === 'number' && maxUsers >= 1 && maxUsers <= 1000) ? maxUsers : DEFAULT_MAX_USERS_SERVER;

        const userProfile: UserProfile = { id: socket.id, name: userName, age: userAge, city: userCity };

        if (!roomData) {
          isNewRoom = true;
          roomData = {
            users: new Map<string, UserProfile>(),
            messages: [],
            retentionPolicy: retentionPolicy || 'none',
            password: password || undefined,
            roomMode: roomMode || 'public',
            maxUsers: effectiveMaxUsers,
          };
          currentActiveRooms.set(roomName, roomData);
          console.log(`[Socket.IO] Room '${roomName}' created by '${userName}'. Mode: ${roomData.roomMode}, Retention: ${roomData.retentionPolicy}, MaxUsers: ${roomData.maxUsers}, Password: ${roomData.password ? 'yes' : 'no'}. Active rooms count: ${currentActiveRooms.size}`);
        } else {
            console.log(`[Socket.IO] Joining existing room '${roomName}'. Stored MaxUsers: ${roomData.maxUsers}, Stored Retention: ${roomData.retentionPolicy}, Stored Mode: ${roomData.roomMode}. User provided maxUsers: ${maxUsers}, retention: ${retentionPolicy}, mode: ${roomMode}. Sticking to stored room settings.`);
        }

        if (roomData.password && !isNewRoom) { 
          if (roomData.password !== password) {
            console.log(`[Socket.IO] Auth failed for user '${userName}' in room '${roomName}': Incorrect password.`);
            socket.emit('auth-failed');
            return;
          }
        }

        if (roomData.users.size >= roomData.maxUsers && !roomData.users.has(socket.id)) {
          console.log(`[Socket.IO] Room '${roomName}' is full (max ${roomData.maxUsers} users). User '${userName}' (${socket.id}) cannot join.`);
          socket.emit('room-full', { roomName, maxUsers: roomData.maxUsers });
          return;
        }

        socket.join(roomName);
        roomData.users.set(socket.id, userProfile); // Store full UserProfile
        console.log(`[Socket.IO] User '${userName}' (Age: ${userAge}, City: ${userCity}) (${socket.id}) successfully joined room: '${roomName}'. Users in room: ${roomData.users.size}/${roomData.maxUsers}`);

        const now = Date.now();
        const retentionMillis = getRetentionMilliseconds(roomData.retentionPolicy);
        const currentMessages = retentionMillis === Infinity
          ? roomData.messages
          : roomData.messages.filter(msg => new Date(msg.timestamp).getTime() >= (now - retentionMillis));

        socket.emit('initial-messages', { 
            messages: currentMessages, 
            retentionPolicy: roomData.retentionPolicy, 
            roomMode: roomData.roomMode, 
            maxUsers: roomData.maxUsers,
            isPasswordProtected: !!roomData.password 
        });
        console.log(`[Socket.IO] Emitted 'initial-messages' to socket ${socket.id} for room '${roomName}' with authoritative settings.`);

        socket.to(roomName).emit('user-joined', userProfile); // Send full UserProfile
        console.log(`[Socket.IO] Emitted 'user-joined' for '${userName}' to room '${roomName}'`);

        const usersInRoomArray: UserProfile[] = Array.from(roomData.users.values()); // Emit array of UserProfile
        io.to(roomName).emit('current-users', usersInRoomArray);
        console.log(`[Socket.IO] Emitted 'current-users' to room '${roomName}'. Count: ${usersInRoomArray.length}`);
      });

      socket.on('send-message', ({ roomName, message, userName }: { roomName: string; message: string; userName: string }) => {
        console.log(`[Socket.IO] 'send-message' event for room '${roomName}' by '${userName}': ${message}`);
        const roomData = currentActiveRooms.get(roomName);
        if (!roomData) {
          console.warn(`[Socket.IO] RoomData not found for '${roomName}' on send-message. Ignoring.`);
          return;
        }

        const newMessage: Message = {
          id: `${socket.id}-${Date.now()}`,
          userName,
          text: message,
          timestamp: new Date().toISOString(),
          type: 'user',
          socketId: socket.id,
        };
        roomData.messages.push(newMessage);
        io.to(roomName).emit('receive-message', newMessage);
      });

      socket.on('send-media-message', ({ roomName, userName, mediaUrl, fileType, fileName }: { roomName: string; userName: string; mediaUrl: string; fileType: 'image' | 'video'; fileName: string }) => {
        console.log(`[Socket.IO] 'send-media-message' event for room '${roomName}' by '${userName}', file: ${fileName}`);
        const roomData = currentActiveRooms.get(roomName);
        if (!roomData) {
          console.warn(`[Socket.IO] RoomData not found for '${roomName}' on send-media-message. Ignoring.`);
          return;
        }
        const newMediaMessage: Message = {
          id: `${socket.id}-${Date.now()}`,
          userName,
          timestamp: new Date().toISOString(),
          type: fileType,
          socketId: socket.id,
          mediaUrl,
          fileName,
        };
        roomData.messages.push(newMediaMessage);
        io.to(roomName).emit('receive-message', newMediaMessage);
      });


      socket.on('disconnect', () => {
        console.log(`[Socket.IO] User disconnected: ${socket.id}. Total connections: ${io.engine.clientsCount}`);
        currentActiveRooms.forEach((roomData, roomName) => {
          if (roomData.users.has(socket.id)) {
            const userProfile = roomData.users.get(socket.id)!;
            roomData.users.delete(socket.id);

            console.log(`[Socket.IO] User '${userProfile.name}' removed from room '${roomName}'. Users remaining: ${roomData.users.size}`);

            io.to(roomName).emit('user-left', userProfile); // Send full UserProfile

            const usersInRoomArray: UserProfile[] = Array.from(roomData.users.values()); // Emit array of UserProfile
            io.to(roomName).emit('current-users', usersInRoomArray);
             console.log(`[Socket.IO] Emitted 'user-left' and 'current-users' to room '${roomName}' after disconnect.`);
          }
        });
      });
    });
    console.log('[SocketHandler] Socket.IO server initialized and event listeners attached.');
  }
  res.end();
}

    