
import type { NextApiRequest, NextApiResponse } from 'next';
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServerType } from 'socket.io';
import type { RoomData, UpdateRoomSettingsPayload, RoomSettingsUpdateNotification, RetentionPolicy } from '@/types';

interface AppData {
  activeRooms: Map<string, RoomData>;
  reportedMessages: ReportedMessageInfo[];
}

interface EnhancedIOServer extends IOServerType {
  appData?: AppData;
}

interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { roomName, password, retentionPolicy, maxUsers } = req.body as UpdateRoomSettingsPayload;

  if (!roomName || typeof roomName !== 'string') {
    return res.status(400).json({ error: 'Room name is required.' });
  }

  const io = res.socket.server.io;

  if (!io || !io.appData || !io.appData.activeRooms) {
    console.error('[API /admin/update-room-settings] Socket server not available or activeRooms data missing.');
    return res.status(500).json({ error: 'Socket server not available or app data uninitialized.' });
  }

  const activeRooms = io.appData.activeRooms;
  const roomData = activeRooms.get(roomName);

  if (!roomData) {
    return res.status(404).json({ error: `Room "${roomName}" not found.` });
  }

  const updateNotification: RoomSettingsUpdateNotification = {};
  let settingsChanged = false;

  if (password !== undefined) { // password can be an empty string (set) or null (remove)
    if (password === null) {
      delete roomData.password;
      console.log(`[API /admin/update-room-settings] Password removed for room: ${roomName}`);
    } else {
      roomData.password = password;
      console.log(`[API /admin/update-room-settings] Password updated for room: ${roomName}`);
    }
    updateNotification.passwordChanged = true;
    settingsChanged = true;
  }

  if (retentionPolicy && roomData.retentionPolicy !== retentionPolicy) {
    roomData.retentionPolicy = retentionPolicy;
    updateNotification.retentionPolicy = retentionPolicy;
    settingsChanged = true;
    console.log(`[API /admin/update-room-settings] Retention policy for room ${roomName} updated to: ${retentionPolicy}`);
  }

  if (typeof maxUsers === 'number' && maxUsers >= 1 && maxUsers <= 1000 && roomData.maxUsers !== maxUsers) {
    roomData.maxUsers = maxUsers;
    updateNotification.maxUsers = maxUsers;
    settingsChanged = true;
    console.log(`[API /admin/update-room-settings] Max users for room ${roomName} updated to: ${maxUsers}`);
  }

  if (settingsChanged) {
    activeRooms.set(roomName, roomData);
    // Notify users in the room about the settings update
    io.to(roomName).emit('room-settings-updated', updateNotification);
    console.log(`[API /admin/update-room-settings] Emitted 'room-settings-updated' to room: ${roomName}`, updateNotification);
    return res.status(200).json({ success: true, message: `Room "${roomName}" settings updated.` });
  } else {
    return res.status(200).json({ success: false, message: 'No changes applied to room settings.' });
  }
}
