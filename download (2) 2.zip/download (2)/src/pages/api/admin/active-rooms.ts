
import type { NextApiRequest, NextApiResponse } from 'next';
import type { RoomData, RetentionPolicy, RoomMode, Message } from '@/types';
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServerType } from 'socket.io';

interface AppData {
  activeRooms: Map<string, RoomData>;
}

interface EnhancedIOServer extends IOServerType {
  appData?: AppData;
}

interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

interface ActiveRoomInfo {
  name: string;
  userCount: number;
  mode: RoomMode;
  hasPassword?: boolean;
  retention: RetentionPolicy;
  messages: Message[];
  maxUsers: number; // Added maxUsers
}

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method === 'GET') {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    console.log('[API /admin/active-rooms] Request received.');
    
    const io = res.socket.server.io;
    const activeRoomsFromIO = io?.appData?.activeRooms;

    if (activeRoomsFromIO) {
      console.log('[API /admin/active-rooms] Accessed activeRooms from io.appData. Size:', activeRoomsFromIO.size);
      if (activeRoomsFromIO.size > 0) {
        console.log('[API /admin/active-rooms] Current activeRooms content (JSON):', JSON.stringify(Array.from(activeRoomsFromIO.entries()), (key, value) => {
          if (value instanceof Map) {
            return Array.from(value.entries()); 
          }
          return value;
        }));
      }

      const roomsArray: ActiveRoomInfo[] = [];
      
      activeRoomsFromIO.forEach((roomData: RoomData, roomName: string) => {
        roomsArray.push({
          name: roomName,
          userCount: roomData.users.size,
          mode: roomData.roomMode,
          hasPassword: !!roomData.password,
          retention: roomData.retentionPolicy,
          messages: roomData.messages || [],
          maxUsers: roomData.maxUsers, 
        });
      });
      
      console.log(`[API /admin/active-rooms] Sending ${roomsArray.length} rooms to admin panel.`);
      res.status(200).json({ activeRooms: roomsArray });
    } else {
      console.error('[API /admin/active-rooms] Critical Error: activeRooms map is not available via io.appData or io instance itself is not available.');
      res.status(200).json({ activeRooms: [] }); 
    }
  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
