
import type { NextApiRequest, NextApiResponse } from 'next';
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServerType } from 'socket.io';
import type { RoomData } from '@/types';

interface AppData {
  activeRooms: Map<string, RoomData>;
}

interface EnhancedIOServer extends IOServerType {
  appData?: AppData;
}

interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { roomName } = req.body;

  if (!roomName || typeof roomName !== 'string') {
    return res.status(400).json({ error: 'Room name is required.' });
  }

  const io = res.socket.server.io;

  if (!io || !io.appData || !io.appData.activeRooms) {
    console.error('[API /admin/delete-room] Socket server not available or activeRooms data missing.');
    return res.status(500).json({ error: 'Socket server not available.' });
  }

  const activeRooms = io.appData.activeRooms;

  if (!activeRooms.has(roomName)) {
    return res.status(404).json({ error: `Room "${roomName}" not found.` });
  }

  try {
    // Notify users in the room that it's being closed
    io.to(roomName).emit('room-closed', { roomName, message: 'This room has been closed by an administrator.' });
    console.log(`[API /admin/delete-room] Emitted 'room-closed' to room: ${roomName}`);

    // Disconnect all users from the room
    // Sockets in the room need to be programmatically disconnected.
    // This is a bit complex with Socket.IO v3/v4 from an external API route.
    // A simpler approach for now is to just delete the room data.
    // Clients will eventually time out or fail to send messages.
    // The 'room-closed' event should prompt clients to leave.

    const roomSockets = io.sockets.adapter.rooms.get(roomName);
    if (roomSockets) {
      roomSockets.forEach(socketId => {
        const socket = io.sockets.sockets.get(socketId);
        if (socket) {
          socket.leave(roomName); // Make the socket leave the room
          // Optionally, disconnect the socket entirely if they are only in this room
          // socket.disconnect(true); 
          console.log(`[API /admin/delete-room] Socket ${socketId} removed from room ${roomName}`);
        }
      });
    }


    activeRooms.delete(roomName);
    console.log(`[API /admin/delete-room] Room "${roomName}" deleted successfully. Active rooms count: ${activeRooms.size}`);
    
    return res.status(200).json({ success: true, message: `Room "${roomName}" deleted.` });
  } catch (error) {
    console.error(`[API /admin/delete-room] Error deleting room "${roomName}":`, error);
    return res.status(500).json({ error: `Failed to delete room "${roomName}".` });
  }
}
