
import type { NextApiRequest, NextApiResponse } from 'next';
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServerType, Socket as ServerSocketType } from 'socket.io';
import type { RoomData } from '@/types';

interface AppData {
  activeRooms: Map<string, RoomData>;
}

interface EnhancedIOServer extends IOServerType {
  appData?: AppData;
}

interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { socketId, roomName } = req.body;

  if (!socketId || typeof socketId !== 'string') {
    return res.status(400).json({ error: 'User socket ID is required.' });
  }
  if (!roomName || typeof roomName !== 'string') {
    return res.status(400).json({ error: 'Room name is required.' });
  }

  const io = res.socket.server.io;

  if (!io || !io.appData || !io.appData.activeRooms) {
    console.error('[API /admin/kick-user] Socket server not available or activeRooms data missing.');
    return res.status(500).json({ error: 'Socket server not available.' });
  }

  const targetSocket: ServerSocketType | undefined = io.sockets.sockets.get(socketId);

  if (!targetSocket) {
    console.log(`[API /admin/kick-user] User with socket ID "${socketId}" not found or not connected.`);
    return res.status(404).json({ error: `User with socket ID "${socketId}" not found.` });
  }

  const roomData = io.appData.activeRooms.get(roomName);
  if (!roomData || !roomData.users.has(socketId)) {
    console.log(`[API /admin/kick-user] User "${socketId}" is not in room "${roomName}".`);
    // User might have already left or is in a different room than expected.
    // Still attempt to make them leave the specified room if they are somehow in it server-side.
  }
  
  try {
    console.log(`[API /admin/kick-user] Kicking user ${socketId} from room ${roomName}`);
    
    // Notify the user they are being kicked
    targetSocket.emit('you-were-kicked', { roomName, message: 'You have been kicked from the room by an administrator.' });
    console.log(`[API /admin/kick-user] Emitted 'you-were-kicked' to socket ${socketId}`);
    
    // Make the socket leave the room
    targetSocket.leave(roomName);
    console.log(`[API /admin/kick-user] Socket ${socketId} forced to leave room ${roomName}`);

    // The 'disconnect' or 'user-left' event from socket.ts should handle updating user lists.
    // If the roomData exists and user was in it, we can manually remove them here as well for immediate consistency,
    // though the 'user-left' event on socket disconnect/leave should handle it.
    if (roomData && roomData.users.has(socketId)) {
      const userName = roomData.users.get(socketId);
      roomData.users.delete(socketId);
      console.log(`[API /admin/kick-user] User "${userName}" (socket ${socketId}) removed from roomData for "${roomName}".`);
      // Manually trigger a user-left notification if needed, but rely on socket.io's native leave first
      // io.to(roomName).emit('user-left', { name: userName, id: socketId });
      // io.to(roomName).emit('current-users', Array.from(roomData.users.values()).map(name => ({name, id: '...'}))); // This would need socket IDs
    }
    
    // Optionally, disconnect the socket entirely if kicking implies full removal from server
    // targetSocket.disconnect(true);

    return res.status(200).json({ success: true, message: `User ${socketId} has been kicked from room ${roomName}.` });
  } catch (error) {
    console.error(`[API /admin/kick-user] Error kicking user "${socketId}" from room "${roomName}":`, error);
    return res.status(500).json({ error: `Failed to kick user.` });
  }
}
