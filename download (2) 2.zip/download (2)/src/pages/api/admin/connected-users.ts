
import type { NextApiRequest, NextApiResponse } from 'next';
import type { RoomData, ConnectedUserInfoForAdmin, UserProfile } from '@/types'; // Updated types
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServerType } from 'socket.io';

interface AppData {
  activeRooms: Map<string, RoomData>;
}

interface EnhancedIOServer extends IOServerType {
  appData?: AppData;
}

interface SocketServer extends HTTPServer {
  io?: EnhancedIOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

// Interface ConnectedUserInfo is removed as ConnectedUserInfoForAdmin from types.ts will be used

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method === 'GET') {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    console.log('[API /admin/connected-users] Request received.');

    const io = res.socket.server.io;
    const activeRoomsFromIO = io?.appData?.activeRooms;

    if (activeRoomsFromIO) {
      console.log('[API /admin/connected-users] Accessed activeRooms from io.appData. Size:', activeRoomsFromIO.size);
      if (activeRoomsFromIO.size > 0) {
         console.log('[API /admin/connected-users] Current activeRooms content (JSON):', JSON.stringify(Array.from(activeRoomsFromIO.entries()), (key, value) => {
          if (value instanceof Map) {
            // Serialize Map of UserProfile correctly
            if (key === 'users' && value instanceof Map) {
              return Array.from(value.entries());
            }
            return Array.from(value.entries());
          }
          return value;
        }));
      }

      const connectedUsers: ConnectedUserInfoForAdmin[] = [];
      
      activeRoomsFromIO.forEach((roomData: RoomData, roomName: string) => {
        if (roomData.users && roomData.users.size > 0) {
          roomData.users.forEach((userProfile: UserProfile, userId: string) => { // userProfile is now UserProfile object
            connectedUsers.push({
              id: userId, // socketId
              name: userProfile.name,
              age: userProfile.age,
              city: userProfile.city,
              roomName: roomName,
            });
          });
        }
      });
      
      console.log(`[API /admin/connected-users] Sending ${connectedUsers.length} users to admin panel.`);
      res.status(200).json({ connectedUsers });
    } else {
      console.error('[API /admin/connected-users] Critical Error: activeRooms map is not available via io.appData or io instance itself is not available.');
      res.status(200).json({ connectedUsers: [] }); 
    }
  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
    
