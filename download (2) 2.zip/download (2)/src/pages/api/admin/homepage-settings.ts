
import type { NextApiRequest, NextApiResponse } from 'next';
import { globalSettings } from '../socket'; // Import the shared settings

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    if (globalSettings) {
      res.status(200).json({ 
        websiteName: globalSettings.websiteName,
        homepageHeroTitle: globalSettings.homepageHeroTitle,
        tagline: globalSettings.tagline,
        footerText: globalSettings.footerText,
        homepageFeatureSectionTitle: globalSettings.homepageFeatureSectionTitle,
        homepageBannerUrl: globalSettings.homepageBannerUrl,
        homepageBannerAltText: globalSettings.homepageBannerAltText,
        feature1Title: globalSettings.feature1Title,
        feature1Description: globalSettings.feature1Description,
        feature2Title: globalSettings.feature2Title,
        feature2Description: globalSettings.feature2Description,
        feature3Title: globalSettings.feature3Title,
        feature3Description: globalSettings.feature3Description,
        termsAndConditionsHTML: globalSettings.termsAndConditionsHTML,
        privacyPolicyHTML: globalSettings.privacyPolicyHTML,
        instagramUrl: globalSettings.instagramUrl,
        linkedinUrl: globalSettings.linkedinUrl,
        youtubeUrl: globalSettings.youtubeUrl,
      });
    } else {
      console.error('API Error: globalSettings is not available.');
      // Provide default fallbacks if globalSettings is somehow not available
      res.status(500).json({ 
        error: 'Global settings are currently unavailable.',
        websiteName: "ChatterBox Rooms (Default)",
        homepageHeroTitle: "Welcome to ChatterBox Rooms (Default)",
        tagline: "Connect, collaborate, and chat in real-time. (Default)",
        footerText: `© ${new Date().getFullYear()} ChatterBox Rooms. (Default)`,
        homepageFeatureSectionTitle: "Why ChatterBox? (Default)",
        homepageBannerUrl: "https://placehold.co/800x300.png",
        homepageBannerAltText: "Chat application banner (Default)",
        feature1Title: "Instant Rooms (Default)",
        feature1Description: "Default description for instant rooms.",
        feature2Title: "AI-Powered Suggestions (Default)",
        feature2Description: "Default description for AI suggestions.",
        feature3Title: "Group Chat Made Easy (Default)",
        feature3Description: "Default description for group chat.",
        termsAndConditionsHTML: "<p>Default Terms and Conditions - Please update from admin panel.</p>",
        privacyPolicyHTML: "<p>Default Privacy Policy - Please update from admin panel.</p>",
        instagramUrl: "",
        linkedinUrl: "",
        youtubeUrl: "",
      });
    }
  } else if (req.method === 'POST') {
    const { 
      websiteName, homepageHeroTitle, tagline, footerText, 
      homepageFeatureSectionTitle, homepageBannerUrl, homepageBannerAltText,
      feature1Title, feature1Description,
      feature2Title, feature2Description,
      feature3Title, feature3Description,
      termsAndConditionsHTML, privacyPolicyHTML,
      instagramUrl, linkedinUrl, youtubeUrl,
    } = req.body;
    
    if (globalSettings) {
      let updated = false;
      if (typeof websiteName === 'string') { globalSettings.websiteName = websiteName; updated = true; }
      if (typeof homepageHeroTitle === 'string') { globalSettings.homepageHeroTitle = homepageHeroTitle; updated = true; }
      if (typeof tagline === 'string') { globalSettings.tagline = tagline; updated = true; }
      if (typeof footerText === 'string') { globalSettings.footerText = footerText; updated = true; }
      if (typeof homepageFeatureSectionTitle === 'string') { globalSettings.homepageFeatureSectionTitle = homepageFeatureSectionTitle; updated = true; }
      if (typeof homepageBannerUrl === 'string') { globalSettings.homepageBannerUrl = homepageBannerUrl; updated = true; }
      if (typeof homepageBannerAltText === 'string') { globalSettings.homepageBannerAltText = homepageBannerAltText; updated = true; }
      if (typeof feature1Title === 'string') { globalSettings.feature1Title = feature1Title; updated = true; }
      if (typeof feature1Description === 'string') { globalSettings.feature1Description = feature1Description; updated = true; }
      if (typeof feature2Title === 'string') { globalSettings.feature2Title = feature2Title; updated = true; }
      if (typeof feature2Description === 'string') { globalSettings.feature2Description = feature2Description; updated = true; }
      if (typeof feature3Title === 'string') { globalSettings.feature3Title = feature3Title; updated = true; }
      if (typeof feature3Description === 'string') { globalSettings.feature3Description = feature3Description; updated = true; }
      if (typeof termsAndConditionsHTML === 'string') { globalSettings.termsAndConditionsHTML = termsAndConditionsHTML; updated = true; }
      if (typeof privacyPolicyHTML === 'string') { globalSettings.privacyPolicyHTML = privacyPolicyHTML; updated = true; }
      if (typeof instagramUrl === 'string') { globalSettings.instagramUrl = instagramUrl; updated = true; }
      if (typeof linkedinUrl === 'string') { globalSettings.linkedinUrl = linkedinUrl; updated = true; }
      if (typeof youtubeUrl === 'string') { globalSettings.youtubeUrl = youtubeUrl; updated = true; }


      if (updated) {
        res.status(200).json({ success: true, message: 'Global settings updated successfully.' });
      } else {
        res.status(400).json({ error: 'No valid settings provided to update.' });
      }
    } else {
      console.error('API Error: Cannot update settings because globalSettings is not available.');
      res.status(500).json({ error: 'Failed to update global settings due to an internal issue.' });
    }
  } else {
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}

    