
import type { NextApiRequest, NextApiResponse } from 'next';
import type { Server as HTTPServer } from 'http';
import type { Socket as NetSocket } from 'net';
import type { Server as IOServer } from 'socket.io';
import type { Message } from '@/types'; // Import Message type

// Define interfaces needed for accessing the socket server
interface SocketServer extends HTTPServer {
  io?: IOServer;
}

interface SocketWithIO extends NetSocket {
  server: SocketServer;
}

interface NextApiResponseWithSocket extends NextApiResponse {
  socket: SocketWithIO;
}

export default function handler(req: NextApiRequest, res: NextApiResponseWithSocket) {
  if (req.method === 'POST') {
    const { message } = req.body;

    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Message is required and must be a non-empty string.' });
    }

    const io = res.socket.server.io;
    if (io) {
      const announcementMessage: Message = {
        id: `admin-announcement-${Date.now()}`,
        text: message,
        timestamp: new Date().toISOString(),
        type: 'admin_announcement',
        userName: 'Admin', // Or a more descriptive name like "System Announcement"
      };
      
      // Emit to all connected clients across all rooms
      io.emit('global-announcement', announcementMessage);
      
      console.log(`Admin announcement sent: ${message}`);
      res.status(200).json({ success: true, message: 'Announcement sent' });
    } else {
      console.error('Socket.IO server not initialized on admin announce API.');
      res.status(500).json({ error: 'Socket server not available. Ensure a socket connection has been made to initialize it.' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
