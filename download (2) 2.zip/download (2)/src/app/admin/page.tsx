
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ShieldCheck, Send, LogIn, LogOut, AlertTriangle, Users, Loader2, ServerCrash, RefreshCw, UserX, UserCog, Palette, CheckCircle, Edit, Save, Settings, Eye, Trash2, LayoutDashboard, FileText, KeyRound, UserCircle2, Briefcase, MapPin, Link as LinkIcon } from 'lucide-react'; // Added Briefcase, MapPin, LinkIcon
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import type { RetentionPolicy, RoomMode, Message, UpdateRoomSettingsPayload, ConnectedUserInfoForAdmin } from '@/types'; // Updated ConnectedUserInfo to ConnectedUserInfoForAdmin
import { themes, DEFAULT_THEME_NAME, type ThemeColors } from '@/lib/themes';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog"


const ADMIN_USERNAME = 'vishhh2'; // MODIFIED
const ADMIN_PASSWORD = 'Khuddi@22'; // MODIFIED

interface ActiveRoomInfo {
  name: string;
  userCount: number;
  mode: RoomMode;
  hasPassword?: boolean;
  retention: RetentionPolicy;
  messages: Message[];
  maxUsers: number;
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  const [announcement, setAnnouncement] = useState('');
  const [isSendingAnnouncement, setIsSendingAnnouncement] = useState(false);

  const [activeRooms, setActiveRooms] = useState<ActiveRoomInfo[]>([]);
  const [isLoadingRooms, setIsLoadingRooms] = useState(false);
  const [roomsError, setRoomsError] = useState('');
  const [roomToDelete, setRoomToDelete] = useState<string | null>(null);
  const [isDeletingRoom, setIsDeletingRoom] = useState(false);

  const [editingRoom, setEditingRoom] = useState<ActiveRoomInfo | null>(null);
  const [editRoomPassword, setEditRoomPassword] = useState('');
  const [editRoomRetention, setEditRoomRetention] = useState<RetentionPolicy>('none');
  const [editRoomMaxUsers, setEditRoomMaxUsers] = useState('');
  const [isUpdatingRoomSettings, setIsUpdatingRoomSettings] = useState(false);
  const [makeRoomPublic, setMakeRoomPublic] = useState(false);


  const [connectedUsers, setConnectedUsers] = useState<ConnectedUserInfoForAdmin[]>([]); // Updated type
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [usersError, setUsersError] = useState('');
  const [currentThemeName, setCurrentThemeName] = useState<string>(DEFAULT_THEME_NAME);
  const [userToKick, setUserToKick] = useState<ConnectedUserInfoForAdmin | null>(null); // Updated type
  const [isKickingUser, setIsKickingUser] = useState(false);


  // Global App Settings states
  const [websiteName, setWebsiteName] = useState('');
  const [homepageHeroTitle, setHomepageHeroTitle] = useState('');
  const [homepageTagline, setHomepageTagline] = useState('');
  const [footerText, setFooterText] = useState('');
  const [homepageFeatureSectionTitle, setHomepageFeatureSectionTitle] = useState('');
  const [homepageBannerUrl, setHomepageBannerUrl] = useState('');
  const [homepageBannerAltText, setHomepageBannerAltText] = useState('');
  const [feature1Title, setFeature1Title] = useState('');
  const [feature1Description, setFeature1Description] = useState('');
  const [feature2Title, setFeature2Title] = useState('');
  const [feature2Description, setFeature2Description] = useState('');
  const [feature3Title, setFeature3Title] = useState('');
  const [feature3Description, setFeature3Description] = useState('');
  const [termsAndConditionsHTML, setTermsAndConditionsHTML] = useState('');
  const [privacyPolicyHTML, setPrivacyPolicyHTML] = useState('');
  const [instagramUrl, setInstagramUrl] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [youtubeUrl, setYoutubeUrl] = useState('');


  const [isLoadingGlobalSettings, setIsLoadingGlobalSettings] = useState(false);
  const [isSavingGeneralSiteSettings, setIsSavingGeneralSiteSettings] = useState(false);
  const [isSavingHomepageContent, setIsSavingHomepageContent] = useState(false);
  const [isSavingPolicyPages, setIsSavingPolicyPages] = useState(false);


  const { toast } = useToast();

  const handleOpenEditRoomDialog = (room: ActiveRoomInfo) => {
    setEditingRoom(room);
    setEditRoomPassword(''); 
    setMakeRoomPublic(false); 
    setEditRoomRetention(room.retention);
    setEditRoomMaxUsers(room.maxUsers.toString());
  };

  const handleUpdateRoomSettings = async () => {
    if (!editingRoom || !isAuthenticated) return;
    setIsUpdatingRoomSettings(true);
    console.log(`[AdminPanel] Updating settings for room: ${editingRoom.name}`);

    const maxUsersNum = parseInt(editRoomMaxUsers, 10);
    if (isNaN(maxUsersNum) || maxUsersNum < 1 || maxUsersNum > 1000) {
      toast({
        title: 'Invalid Max Users',
        description: 'Max users must be a number between 1 and 1000.',
        variant: 'destructive',
      });
      setIsUpdatingRoomSettings(false);
      return;
    }
    
    const payload: UpdateRoomSettingsPayload = {
      roomName: editingRoom.name,
      retentionPolicy: editRoomRetention,
      maxUsers: maxUsersNum,
    };

    if (makeRoomPublic) {
      payload.password = null; 
    } else if (editRoomPassword.trim()) {
      payload.password = editRoomPassword.trim();
    }

    try {
      const response = await fetch('/api/admin/update-room-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to parse error from server' }));
        throw new Error(errorData.error || 'Failed to update room settings');
      }
      toast({
        title: 'Room Settings Updated',
        description: `Settings for room "${editingRoom.name}" have been updated.`,
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      setEditingRoom(null); 
      fetchActiveRooms(); 
    } catch (error: any) {
      console.error(`[AdminPanel] Failed to update settings for room "${editingRoom.name}":`, error);
      toast({
        title: 'Error Updating Settings',
        description: error.message || `Could not update settings for room "${editingRoom.name}".`,
        variant: 'destructive',
      });
    } finally {
      setIsUpdatingRoomSettings(false);
    }
  };


  const applyTheme = (themeName: string) => {
    const themeColors = themes[themeName];
    if (!themeColors) {
      console.warn(`[AdminPanel] Theme "${themeName}" not found. Applying default.`);
      applyTheme(DEFAULT_THEME_NAME);
      return;
    }
    for (const [variable, value] of Object.entries(themeColors)) {
      document.documentElement.style.setProperty(variable, value);
    }
    localStorage.setItem('adminAppliedThemeName', themeName);
    setCurrentThemeName(themeName);
    toast({
      title: 'Theme Applied',
      description: `"${themeName.replace(/([A-Z])/g, ' $1').trim()}" theme has been applied.`,
      action: <CheckCircle className="h-5 w-5 text-green-500" />,
    });
  };

  const resetThemeToDefault = () => {
    applyTheme(DEFAULT_THEME_NAME);
     toast({
      title: 'Theme Reset',
      description: 'Theme has been reset to default.',
    });
  };

  const fetchGlobalSettings = async () => {
    if (!isAuthenticated) return;
    console.log('[AdminPanel] Fetching global settings...');
    setIsLoadingGlobalSettings(true);
    try {
      const response = await fetch('/api/admin/homepage-settings', { cache: 'no-store' });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: "Failed to parse error from server" }));
        throw new Error(errorData.error || 'Failed to fetch global settings');
      }
      const data = await response.json().catch(() => {
        throw new Error("Failed to parse settings data from server.");
      });
      console.log('[AdminPanel] Global settings received:', data);
      setWebsiteName(data.websiteName || '');
      setHomepageHeroTitle(data.homepageHeroTitle || '');
      setHomepageTagline(data.tagline || '');
      setFooterText(data.footerText || '');
      setHomepageFeatureSectionTitle(data.homepageFeatureSectionTitle || '');
      setHomepageBannerUrl(data.homepageBannerUrl || '');
      setHomepageBannerAltText(data.homepageBannerAltText || '');
      setFeature1Title(data.feature1Title || '');
      setFeature1Description(data.feature1Description || '');
      setFeature2Title(data.feature2Title || '');
      setFeature2Description(data.feature2Description || '');
      setFeature3Title(data.feature3Title || '');
      setFeature3Description(data.feature3Description || '');
      setTermsAndConditionsHTML(data.termsAndConditionsHTML || '');
      setPrivacyPolicyHTML(data.privacyPolicyHTML || '');
      setInstagramUrl(data.instagramUrl || '');
      setLinkedinUrl(data.linkedinUrl || '');
      setYoutubeUrl(data.youtubeUrl || '');

    } catch (error: any) {
      console.error('[AdminPanel] Failed to fetch global settings:', error);
      toast({
        title: 'Error Fetching Settings',
        description: error.message || 'Could not load global settings.',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingGlobalSettings(false);
    }
  };

  const handleSaveGeneralSiteSettings = async () => {
    if (!isAuthenticated) return;
    setIsSavingGeneralSiteSettings(true);
    console.log('[AdminPanel] Saving General Site settings...');
    try {
      const response = await fetch('/api/admin/homepage-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          websiteName,
          footerText,
          instagramUrl,
          linkedinUrl,
          youtubeUrl,
        }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({error: "Failed to parse error from server"}));
        throw new Error(errorData.error || 'Failed to save general site settings');
      }
      toast({
        title: 'General Site Settings Saved',
        description: 'Website name, footer text and social media links have been updated.',
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      console.log('[AdminPanel] General Site settings saved.');
    } catch (error: any) {
      console.error('[AdminPanel] Failed to save general site settings:', error);
      toast({
        title: 'Error Saving Settings',
        description: error.message || 'Could not save general site settings.',
        variant: 'destructive',
      });
    } finally {
      setIsSavingGeneralSiteSettings(false);
    }
  };

  const handleSaveHomepageContent = async () => {
    if (!isAuthenticated) return;
    setIsSavingHomepageContent(true);
    console.log('[AdminPanel] Saving Homepage Content settings...');
    try {
      const response = await fetch('/api/admin/homepage-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          homepageHeroTitle,
          tagline: homepageTagline,
          homepageBannerUrl,
          homepageBannerAltText,
          homepageFeatureSectionTitle,
          feature1Title, feature1Description,
          feature2Title, feature2Description,
          feature3Title, feature3Description,
        }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({error: "Failed to parse error from server"}));
        throw new Error(errorData.error || 'Failed to save homepage content settings');
      }
      toast({
        title: 'Homepage Content Saved',
        description: 'Homepage text and feature content have been updated.',
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      console.log('[AdminPanel] Homepage Content settings saved.');
    } catch (error: any) {
      console.error('[AdminPanel] Failed to save homepage content settings:', error);
      toast({
        title: 'Error Saving Settings',
        description: error.message || 'Could not save homepage content settings.',
        variant: 'destructive',
      });
    } finally {
      setIsSavingHomepageContent(false);
    }
  };

  const handleSavePolicyPages = async () => {
    if (!isAuthenticated) return;
    setIsSavingPolicyPages(true);
    console.log('[AdminPanel] Saving Policy Pages content...');
    try {
      const response = await fetch('/api/admin/homepage-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          termsAndConditionsHTML,
          privacyPolicyHTML,
        }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({error: "Failed to parse error from server"}));
        throw new Error(errorData.error || 'Failed to save policy pages content');
      }
      toast({
        title: 'Policy Pages Saved',
        description: 'Terms & Conditions and Privacy Policy content has been updated.',
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      console.log('[AdminPanel] Policy Pages content saved.');
    } catch (error: any) {
      console.error('[AdminPanel] Failed to save policy pages content:', error);
      toast({
        title: 'Error Saving Settings',
        description: error.message || 'Could not save policy pages content.',
        variant: 'destructive',
      });
    } finally {
      setIsSavingPolicyPages(false);
    }
  };


  useEffect(() => {
    const storedAuth = localStorage.getItem('adminAuthenticated');
    if (storedAuth === 'true') {
      console.log('[AdminPanel] Admin already authenticated from localStorage.');
      setIsAuthenticated(true);
    }
    const savedThemeName = localStorage.getItem('adminAppliedThemeName');
    if (savedThemeName && themes[savedThemeName]) {
      setCurrentThemeName(savedThemeName);
    } else {
      setCurrentThemeName(DEFAULT_THEME_NAME);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchActiveRooms = async () => {
    if (!isAuthenticated) return;
    console.log('[AdminPanel] Fetching active rooms...');
    setIsLoadingRooms(true);
    setRoomsError('');
    try {
      const response = await fetch('/api/admin/active-rooms', { cache: 'no-store' });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({error: "Failed to parse error from server"}));
        throw new Error(errorData.error || `Failed to fetch active rooms: ${response.statusText}`);
      }
      const data = await response.json().catch(() => {
        setActiveRooms([]); 
        throw new Error("Failed to parse active rooms data from server.");
      });
      setActiveRooms(data.activeRooms || []);
      if (!data.activeRooms || data.activeRooms.length === 0) {
        console.log('[AdminPanel] No active rooms found from API.');
      } else {
        console.log('[AdminPanel] Active rooms received:', data.activeRooms);
      }
    } catch (error: any) {
      console.error('[AdminPanel] Failed to fetch active rooms:', error);
      setRoomsError(error.message || 'An unexpected error occurred while fetching rooms.');
      setActiveRooms([]); 
      toast({
        title: 'Error Fetching Rooms',
        description: error.message || 'Could not load active rooms.',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingRooms(false);
    }
  };

  const handleDeleteRoom = async () => {
    if (!roomToDelete || !isAuthenticated) return;
    setIsDeletingRoom(true);
    console.log(`[AdminPanel] Attempting to delete room: ${roomToDelete}`);
    try {
      const response = await fetch('/api/admin/delete-room', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomName: roomToDelete }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to parse error from server' }));
        throw new Error(errorData.error || 'Failed to delete room');
      }
      toast({
        title: 'Room Deleted',
        description: `Room "${roomToDelete}" has been successfully deleted.`,
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      console.log(`[AdminPanel] Room "${roomToDelete}" deleted.`);
      setRoomToDelete(null);
      fetchActiveRooms();
    } catch (error: any) {
      console.error(`[AdminPanel] Failed to delete room "${roomToDelete}":`, error);
      toast({
        title: 'Error Deleting Room',
        description: error.message || `Could not delete room "${roomToDelete}".`,
        variant: 'destructive',
      });
    } finally {
      setIsDeletingRoom(false);
    }
  };

  const fetchConnectedUsers = async () => {
    if (!isAuthenticated) return;
    console.log('[AdminPanel] Fetching connected users...');
    setIsLoadingUsers(true);
    setUsersError('');
    try {
      const response = await fetch('/api/admin/connected-users', { cache: 'no-store' });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({error: "Failed to parse error from server"}));
        throw new Error(errorData.error || `Failed to fetch connected users: ${response.statusText}`);
      }
      const data = await response.json().catch(() => {
        setConnectedUsers([]); 
        throw new Error("Failed to parse connected users data from server.");
      });
      setConnectedUsers(data.connectedUsers || []);
       if (!data.connectedUsers || data.connectedUsers.length === 0) {
        console.log('[AdminPanel] No connected users found from API.');
      } else {
        console.log('[AdminPanel] Connected users received:', data.connectedUsers);
      }
    } catch (error: any) {
      console.error('[AdminPanel] Failed to fetch connected users:', error);
      setUsersError(error.message || 'An unexpected error occurred while fetching users.');
      setConnectedUsers([]); 
      toast({
        title: 'Error Fetching Users',
        description: error.message || 'Could not load connected users.',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const handleKickUser = async () => {
    if (!userToKick || !isAuthenticated) return;
    setIsKickingUser(true);
    console.log(`[AdminPanel] Attempting to kick user: ${userToKick.name} (ID: ${userToKick.id}) from room: ${userToKick.roomName}`);
    try {
      const response = await fetch('/api/admin/kick-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ socketId: userToKick.id, roomName: userToKick.roomName }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to parse error from server' }));
        throw new Error(errorData.error || 'Failed to kick user');
      }
      toast({
        title: 'User Kicked',
        description: `User "${userToKick.name}" has been kicked from room "${userToKick.roomName}".`,
        action: <CheckCircle className="h-5 w-5 text-green-500" />,
      });
      console.log(`[AdminPanel] User "${userToKick.name}" kicked.`);
      setUserToKick(null);
      fetchConnectedUsers(); 
      fetchActiveRooms(); 
    } catch (error: any) {
      console.error(`[AdminPanel] Failed to kick user "${userToKick.name}":`, error);
      toast({
        title: 'Error Kicking User',
        description: error.message || `Could not kick user "${userToKick.name}".`,
        variant: 'destructive',
      });
    } finally {
      setIsKickingUser(false);
    }
  };


  useEffect(() => {
    if (isAuthenticated) {
      console.log('[AdminPanel] Authenticated. Fetching initial admin data.');
      fetchActiveRooms();
      fetchConnectedUsers();
      fetchGlobalSettings();
    } else {
      console.log('[AdminPanel] Not authenticated. Clearing admin data.');
      setActiveRooms([]);
      setConnectedUsers([]);
      setWebsiteName('');
      setHomepageHeroTitle('');
      setHomepageTagline('');
      setFooterText('');
      setHomepageFeatureSectionTitle('');
      setHomepageBannerUrl('');
      setHomepageBannerAltText('');
      setFeature1Title(''); setFeature1Description('');
      setFeature2Title(''); setFeature2Description('');
      setFeature3Title(''); setFeature3Description('');
      setTermsAndConditionsHTML('');
      setPrivacyPolicyHTML('');
      setInstagramUrl('');
      setLinkedinUrl('');
      setYoutubeUrl('');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);


  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    if (usernameInput === ADMIN_USERNAME && passwordInput === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      localStorage.setItem('adminAuthenticated', 'true');
      setUsernameInput('');
      setPasswordInput('');
      console.log('[AdminPanel] Login successful.');
      toast({
        title: 'Login Successful',
        description: 'Welcome, Admin!',
      });
    } else {
      setLoginError('Invalid username or password.');
      console.log('[AdminPanel] Login failed: Invalid credentials.');
      toast({
        title: 'Login Failed',
        description: 'Invalid username or password.',
        variant: 'destructive',
      });
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('adminAuthenticated');
    console.log('[AdminPanel] Logged out.');
    toast({
      title: 'Logged Out',
      description: 'You have been successfully logged out.',
    });
  };

  const handleSendAnnouncement = async () => {
    if (!announcement.trim()) {
      toast({
        title: 'Error',
        description: 'Announcement message cannot be empty.',
        variant: 'destructive',
      });
      return;
    }
    setIsSendingAnnouncement(true);
    console.log('[AdminPanel] Sending announcement:', announcement);
    try {
      const response = await fetch('/api/admin/announce', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: announcement }),
      });
      const result = await response.json();
      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Announcement sent successfully!',
        });
        setAnnouncement('');
        console.log('[AdminPanel] Announcement sent successfully.');
      } else {
        toast({
          title: 'Error',
          description: result.error || 'Failed to send announcement.',
          variant: 'destructive',
        });
        console.error('[AdminPanel] Failed to send announcement:', result.error);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'An unexpected error occurred.',
        variant: 'destructive',
      });
      console.error('[AdminPanel] Exception sending announcement:', error);
    } finally {
      setIsSendingAnnouncement(false);
    }
  };

  const getRetentionPolicyText = (policy: string | undefined) => {
    if (!policy) return 'Permanent';
    switch (policy) {
      case '24h': return '24 Hours';
      case '48h': return '48 Hours';
      case '3d': return '3 Days';
      case '7d': return '7 Days';
      case '30d': return '30 Days';
      case 'none':
      default: return 'Permanent';
    }
  };


  if (!isAuthenticated) {
    return (
      <div className="container mx-auto py-8 px-4 flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <ShieldCheck className="h-16 w-16 text-primary" />
            </div>
            <CardTitle className="text-2xl text-primary">Admin Login</CardTitle>
            <CardDescription>Please enter your credentials to access the admin panel.</CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="admin"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  required
                />
              </div>
              {loginError && (
                <p className="text-sm text-destructive flex items-center">
                  <AlertTriangle className="mr-1 h-4 w-4" />
                  {loginError}
                </p>
              )}
            </CardContent>
            <CardFooter className="flex flex-col">
              <Button type="submit" className="w-full">
                <LogIn className="mr-2 h-4 w-4" /> Login
              </Button>
               <p className="mt-4 text-xs text-muted-foreground text-center">
                (For prototype: user: {ADMIN_USERNAME}, pass: {ADMIN_PASSWORD})
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="mb-10 text-center border-b pb-6">
        <div className="flex justify-between items-center">
            <div></div> 
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-primary flex items-center justify-center">
                <ShieldCheck className="mr-3 h-10 w-10 sm:h-12 sm:w-12" />
                Admin Panel
            </h1>
            <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
        </div>
        <p className="mt-4 text-md sm:text-lg text-muted-foreground max-w-2xl mx-auto">
          Welcome to the ChatterBox Rooms administration area. Current theme: <Badge variant={currentThemeName === DEFAULT_THEME_NAME ? 'secondary' : 'default'}>{currentThemeName.replace(/([A-Z])/g, ' $1').trim()}</Badge>
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-xl text-primary flex items-center"><UserCircle2 className="mr-2 h-5 w-5"/>Admin Profile</CardTitle>
            <CardDescription>Your administrator profile details.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-xs text-muted-foreground">Username</Label>
              <p className="text-sm font-medium">{ADMIN_USERNAME}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Role</Label>
              <p className="text-sm font-medium">Administrator</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Status</Label>
              <p className="text-sm font-medium text-green-600">Active</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-xl text-primary">Send Global Announcement</CardTitle>
            <CardDescription>Broadcast a message to all active chat rooms.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="text"
              placeholder="Enter announcement message..."
              value={announcement}
              onChange={(e) => setAnnouncement(e.target.value)}
              disabled={isSendingAnnouncement}
            />
            <Button onClick={handleSendAnnouncement} disabled={isSendingAnnouncement || !announcement.trim()} className="w-full">
              {isSendingAnnouncement ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending...</>) : <><Send className="mr-2 h-4 w-4" /> Send Announcement</>}
            </Button>
          </CardContent>
        </Card>

        <AlertDialog open={!!roomToDelete} onOpenChange={(open) => !open && setRoomToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to delete this room?</AlertDialogTitle>
              <AlertDialogDescription>
                This action will permanently delete the room "{roomToDelete}" and its current messages. Users in the room will be notified. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setRoomToDelete(null)} disabled={isDeletingRoom}>Cancel</AlertDialogCancel>
              <Button
                variant="destructive"
                onClick={handleDeleteRoom}
                disabled={isDeletingRoom}
              >
                {isDeletingRoom ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                Delete Room
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <Dialog open={!!editingRoom} onOpenChange={(open) => !open && setEditingRoom(null)}>
          <DialogContent className="sm:max-w-[480px]">
            <DialogHeader>
              <DialogTitle>Edit Room: {editingRoom?.name}</DialogTitle>
              <DialogDescription>
                Update the settings for this chat room. Click save when you're done.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="editRoomPassword" className="text-right col-span-1">
                  Password
                </Label>
                <Input
                  id="editRoomPassword"
                  type="text"
                  placeholder={editingRoom?.hasPassword ? "Enter new or leave blank to keep current" : "Leave blank for no password"}
                  value={editRoomPassword}
                  onChange={(e) => { setEditRoomPassword(e.target.value); if (e.target.value) setMakeRoomPublic(false); }}
                  className="col-span-3"
                  disabled={isUpdatingRoomSettings || makeRoomPublic}
                />
              </div>
               <div className="grid grid-cols-4 items-center gap-4">
                <div className="col-start-2 col-span-3 flex items-center space-x-2">
                  <input type="checkbox" id="makeRoomPublic" checked={makeRoomPublic} onChange={(e) => {setMakeRoomPublic(e.target.checked); if(e.target.checked) setEditRoomPassword('');}} disabled={isUpdatingRoomSettings} />
                  <Label htmlFor="makeRoomPublic" className="text-sm font-normal">
                    Make room public (remove password)
                  </Label>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="editRoomRetention" className="text-right col-span-1">
                  Retention
                </Label>
                <Select 
                  value={editRoomRetention} 
                  onValueChange={(value) => setEditRoomRetention(value as RetentionPolicy)}
                  disabled={isUpdatingRoomSettings}
                >
                  <SelectTrigger className="col-span-3" id="editRoomRetention">
                    <SelectValue placeholder="Select retention period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Permanent (None)</SelectItem>
                    <SelectItem value="24h">24 Hours</SelectItem>
                    <SelectItem value="48h">48 Hours</SelectItem>
                    <SelectItem value="3d">3 Days</SelectItem>
                    <SelectItem value="7d">7 Days</SelectItem>
                    <SelectItem value="30d">30 Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="editRoomMaxUsers" className="text-right col-span-1">
                  Max Users
                </Label>
                <Input
                  id="editRoomMaxUsers"
                  type="number"
                  value={editRoomMaxUsers}
                  onChange={(e) => setEditRoomMaxUsers(e.target.value)}
                  min="1"
                  max="1000"
                  className="col-span-3"
                  disabled={isUpdatingRoomSettings}
                />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                 <Button type="button" variant="outline" disabled={isUpdatingRoomSettings}>Cancel</Button>
              </DialogClose>
              <Button type="button" onClick={handleUpdateRoomSettings} disabled={isUpdatingRoomSettings}>
                {isUpdatingRoomSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>


        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl text-primary flex items-center"><Eye className="mr-2 h-5 w-5"/>Active Rooms &amp; Messages</CardTitle>
              <CardDescription>View active rooms, user counts, messages, and manage rooms.</CardDescription>
            </div>
            <Button onClick={fetchActiveRooms} variant="outline" size="icon" disabled={isLoadingRooms} aria-label="Refresh active rooms">
              <RefreshCw className={`h-4 w-4 ${isLoadingRooms ? 'animate-spin' : ''}`} />
            </Button>
          </CardHeader>
          <CardContent>
            {isLoadingRooms && (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="mr-2 h-6 w-6 animate-spin text-primary" />
                <p className="text-muted-foreground">Loading rooms...</p>
              </div>
            )}
            {roomsError && !isLoadingRooms && (
              <div className="flex flex-col items-center justify-center py-4 text-destructive">
                <ServerCrash className="mr-2 h-8 w-8 mb-2" />
                <p className="font-semibold">Error loading rooms</p>
                <p className="text-sm text-center">{roomsError}</p>
                <Button onClick={fetchActiveRooms} variant="outline" size="sm" className="mt-3">
                  Try Again
                </Button>
              </div>
            )}
            {!isLoadingRooms && !roomsError && activeRooms.length === 0 && (
              <p className="text-muted-foreground text-center py-4">No active rooms found.</p>
            )}
            {!isLoadingRooms && !roomsError && activeRooms.length > 0 && (
              <Accordion type="single" collapsible className="w-full">
                {activeRooms.map((room) => (
                  <AccordionItem value={room.name} key={room.name}>
                    <AccordionTrigger>
                      <div className="flex justify-between items-center w-full pr-2">
                        <div className="truncate">
                          <span className="font-semibold text-foreground" title={room.name}>{room.name}</span>
                          <div className="text-xs text-muted-foreground mt-1 space-x-2 flex flex-wrap items-center">
                            <span>Mode: <Badge variant="outline" className="text-xs">{room.mode}</Badge></span>
                            {room.hasPassword && <Badge variant="outline" className="text-xs text-accent border-accent">Private <KeyRound className="ml-1 h-3 w-3"/></Badge>}
                            <span>Retention: <Badge variant="outline" className="text-xs">{getRetentionPolicyText(room.retention)}</Badge></span>
                            <span>Max Users: <Badge variant="outline" className="text-xs">{room.maxUsers}</Badge></span>
                          </div>
                        </div>
                        <Badge variant={room.userCount > 0 ? "default" : "secondary"}>
                          {room.userCount} user{room.userCount !== 1 ? 's' : ''}
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenEditRoomDialog(room)}
                          disabled={isUpdatingRoomSettings && editingRoom?.name === room.name}
                        >
                          <Edit className="mr-2 h-4 w-4" /> Edit Settings
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => setRoomToDelete(room.name)}
                          disabled={isDeletingRoom}
                        >
                          <Trash2 className="mr-2 h-4 w-4" /> Delete Room
                        </Button>
                      </div>
                      <ScrollArea className="h-[180px] mt-2 border rounded-md p-3 bg-muted/20">
                        {room.messages.length > 0 ? (
                          room.messages.map((msg) => (
                            <div key={msg.id} className="text-xs mb-2 p-2 rounded bg-background shadow-sm border">
                              <div className="flex justify-between items-center mb-1">
                                <span className="font-semibold text-primary truncate" title={msg.userName}>{msg.userName}</span>
                                <span className="text-muted-foreground/80 text-[10px]">
                                  {new Date(msg.timestamp).toLocaleTimeString()} - {new Date(msg.timestamp).toLocaleDateString()}
                                </span>
                              </div>
                              {msg.text && <p className="whitespace-pre-wrap break-words">{msg.text}</p>}
                              {msg.type === 'image' && <p className="italic text-muted-foreground">[Image: {msg.fileName || 'image'}]</p>}
                              {msg.type === 'video' && <p className="italic text-muted-foreground">[Video: {msg.fileName || 'video'}]</p>}
                              {msg.type === 'admin_announcement' && <p className="italic text-accent">[Admin Announcement]</p>}
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-muted-foreground text-center py-4">No messages in this room.</p>
                        )}
                      </ScrollArea>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </CardContent>
        </Card>

        <AlertDialog open={!!userToKick} onOpenChange={(open) => !open && setUserToKick(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to kick this user?</AlertDialogTitle>
              <AlertDialogDescription>
                User "{userToKick?.name}" will be removed from room "{userToKick?.roomName}". They can rejoin if the room is public or they have the password.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setUserToKick(null)} disabled={isKickingUser}>Cancel</AlertDialogCancel>
              <Button
                variant="destructive"
                onClick={handleKickUser}
                disabled={isKickingUser}
              >
                {isKickingUser ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserX className="mr-2 h-4 w-4" />}
                Kick User
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>


        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
           <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl text-primary flex items-center"><UserCog className="mr-2 h-5 w-5"/>Connected Users</CardTitle>
              <CardDescription>View connected users and their details. Kick users if necessary.</CardDescription>
            </div>
            <Button onClick={fetchConnectedUsers} variant="outline" size="icon" disabled={isLoadingUsers} aria-label="Refresh connected users">
              <RefreshCw className={`h-4 w-4 ${isLoadingUsers ? 'animate-spin' : ''}`} />
            </Button>
          </CardHeader>
          <CardContent>
             {isLoadingUsers && (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="mr-2 h-6 w-6 animate-spin text-primary" />
                <p className="text-muted-foreground">Loading users...</p>
              </div>
            )}
            {usersError && !isLoadingUsers && (
              <div className="flex flex-col items-center justify-center py-4 text-destructive">
                <ServerCrash className="mr-2 h-8 w-8 mb-2" />
                <p className="font-semibold">Error loading users</p>
                <p className="text-sm text-center">{usersError}</p>
                <Button onClick={fetchConnectedUsers} variant="outline" size="sm" className="mt-3">
                  Try Again
                </Button>
              </div>
            )}
            {!isLoadingUsers && !usersError && connectedUsers.length === 0 && (
              <p className="text-muted-foreground text-center py-4">No users currently connected.</p>
            )}
            {!isLoadingUsers && !usersError && connectedUsers.length > 0 && (
              <ScrollArea className="h-[200px] pr-3">
                <ul className="space-y-3">
                  {connectedUsers.map((user) => (
                    <li key={user.id} className="p-3 border rounded-md shadow-sm bg-background hover:bg-secondary/30 transition-colors">
                      <div className="flex justify-between items-start">
                        <div className="flex-grow">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-semibold text-foreground truncate" title={user.name}>{user.name}</span>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-xs ml-2 shrink-0" 
                              onClick={() => setUserToKick(user)}
                              disabled={isKickingUser && userToKick?.id === user.id}
                            >
                               <UserX className="mr-1 h-3 w-3"/> Kick
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">Room: <Badge variant="outline" className="text-xs">{user.roomName}</Badge></p>
                          {user.age && <p className="text-xs text-muted-foreground flex items-center"><Briefcase className="h-3 w-3 mr-1"/>Age: {user.age}</p>}
                          {user.city && <p className="text-xs text-muted-foreground flex items-center"><MapPin className="h-3 w-3 mr-1"/>City: {user.city}</p>}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-xl text-primary flex items-center"><Palette className="mr-2 h-5 w-5"/>Appearance Settings</CardTitle>
            <CardDescription>Adjust the look of the application (client-side only).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                onClick={() => applyTheme('defaultLight')}
                variant={currentThemeName === 'defaultLight' ? 'default' : 'outline'}
                className="w-full"
              >
                Default Light
              </Button>
              <Button
                onClick={() => applyTheme('deepOceanDark')}
                variant={currentThemeName === 'deepOceanDark' ? 'default' : 'outline'}
                className="w-full"
              >
                Deep Ocean Dark
              </Button>
              <Button
                onClick={() => applyTheme('forestCalm')}
                variant={currentThemeName === 'forestCalm' ? 'default' : 'outline'}
                className="w-full"
              >
                Forest Calm
              </Button>
              <Button
                onClick={resetThemeToDefault}
                variant="secondary"
                className="w-full"
              >
                Reset to Default
              </Button>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Theme changes are saved in your browser's local storage.
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 md:col-span-2 lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-2xl text-primary">Global App &amp; Homepage Settings</CardTitle>
            <CardDescription>Customize general site information, homepage content, and policy pages.</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingGlobalSettings ? (
                 <div className="flex items-center justify-center py-6">
                    <Loader2 className="mr-2 h-6 w-6 animate-spin" /> <span>Loading global settings...</span>
                 </div>
            ) : (
              <Accordion type="multiple" className="w-full space-y-4">
                <AccordionItem value="general-site-settings">
                  <AccordionTrigger className="text-lg hover:no-underline">
                    <div className="flex items-center">
                      <Settings className="mr-3 h-5 w-5 text-primary" /> General Site Settings
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-6 pt-4">
                    <div>
                      <Label htmlFor="websiteName">Website Name</Label>
                      <Input
                        id="websiteName"
                        placeholder="Enter the website name (e.g., My Chat App)"
                        value={websiteName}
                        onChange={(e) => setWebsiteName(e.target.value)}
                        disabled={isSavingGeneralSiteSettings}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="footerText">Footer Text</Label>
                      <Input
                        id="footerText"
                        placeholder="Enter footer text (e.g., © 2024 My Company)"
                        value={footerText}
                        onChange={(e) => setFooterText(e.target.value)}
                        disabled={isSavingGeneralSiteSettings}
                        className="mt-1"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Tip: Use `© ${"${new Date().getFullYear()}"}` for the current year.</p>
                    </div>
                    <div className="mt-4 space-y-2">
                        <Label htmlFor="instagramUrl" className="flex items-center"><LinkIcon className="mr-2 h-4 w-4 text-muted-foreground"/>Instagram URL</Label>
                        <Input id="instagramUrl" placeholder="https://instagram.com/yourprofile" value={instagramUrl} onChange={(e) => setInstagramUrl(e.target.value)} disabled={isSavingGeneralSiteSettings} className="mt-1"/>
                    </div>
                    <div className="mt-4 space-y-2">
                        <Label htmlFor="linkedinUrl" className="flex items-center"><LinkIcon className="mr-2 h-4 w-4 text-muted-foreground"/>LinkedIn URL</Label>
                        <Input id="linkedinUrl" placeholder="https://linkedin.com/in/yourprofile" value={linkedinUrl} onChange={(e) => setLinkedinUrl(e.target.value)} disabled={isSavingGeneralSiteSettings} className="mt-1"/>
                    </div>
                    <div className="mt-4 space-y-2">
                        <Label htmlFor="youtubeUrl" className="flex items-center"><LinkIcon className="mr-2 h-4 w-4 text-muted-foreground"/>YouTube URL</Label>
                        <Input id="youtubeUrl" placeholder="https://youtube.com/yourchannel" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} disabled={isSavingGeneralSiteSettings} className="mt-1"/>
                    </div>
                    <Button onClick={handleSaveGeneralSiteSettings} disabled={isSavingGeneralSiteSettings} className="w-full mt-4">
                      {isSavingGeneralSiteSettings ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="mr-2 h-4 w-4" /> Save General Site Settings</>}
                    </Button>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="homepage-content">
                  <AccordionTrigger className="text-lg hover:no-underline">
                     <div className="flex items-center">
                        <LayoutDashboard className="mr-3 h-5 w-5 text-primary" /> Homepage Content
                     </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-6 pt-4">
                    <div>
                      <Label htmlFor="homepageHeroTitle">Homepage Hero Title</Label>
                      <Input
                        id="homepageHeroTitle"
                        placeholder="Enter the main title for the homepage"
                        value={homepageHeroTitle}
                        onChange={(e) => setHomepageHeroTitle(e.target.value)}
                        disabled={isSavingHomepageContent}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="homepageTagline">Homepage Tagline</Label>
                      <Textarea
                        id="homepageTagline"
                        placeholder="Enter the homepage tagline..."
                        value={homepageTagline}
                        onChange={(e) => setHomepageTagline(e.target.value)}
                        rows={3}
                        disabled={isSavingHomepageContent}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="homepageBannerUrl">Homepage Banner Image URL</Label>
                      <Input
                        id="homepageBannerUrl"
                        placeholder="https://example.com/banner.jpg or /images/banner.png"
                        value={homepageBannerUrl}
                        onChange={(e) => setHomepageBannerUrl(e.target.value)}
                        disabled={isSavingHomepageContent}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="homepageBannerAltText">Homepage Banner Alt Text</Label>
                      <Input
                        id="homepageBannerAltText"
                        placeholder="Descriptive text for the homepage banner image"
                        value={homepageBannerAltText}
                        onChange={(e) => setHomepageBannerAltText(e.target.value)}
                        disabled={isSavingHomepageContent}
                        className="mt-1"
                      />
                    </div>
                    <hr className="my-4 border-border" />
                    <h3 className="text-md font-medium text-foreground">Homepage Features Section</h3>
                    <div>
                      <Label htmlFor="homepageFeatureSectionTitle">Features Section Title</Label>
                      <Input
                        id="homepageFeatureSectionTitle"
                        placeholder="e.g., Why Choose Us?"
                        value={homepageFeatureSectionTitle}
                        onChange={(e) => setHomepageFeatureSectionTitle(e.target.value)}
                        disabled={isSavingHomepageContent}
                        className="mt-1"
                      />
                    </div>
                    <div className="p-4 border rounded-md space-y-2 bg-muted/20">
                      <Label htmlFor="feature1Title" className="font-semibold">Feature 1 Title</Label>
                      <Input id="feature1Title" value={feature1Title} onChange={(e) => setFeature1Title(e.target.value)} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                      <Label htmlFor="feature1Description" className="font-semibold">Feature 1 Description</Label>
                      <Textarea id="feature1Description" value={feature1Description} onChange={(e) => setFeature1Description(e.target.value)} rows={2} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                    </div>
                    <div className="p-4 border rounded-md space-y-2 bg-muted/20">
                      <Label htmlFor="feature2Title" className="font-semibold">Feature 2 Title</Label>
                      <Input id="feature2Title" value={feature2Title} onChange={(e) => setFeature2Title(e.target.value)} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                      <Label htmlFor="feature2Description" className="font-semibold">Feature 2 Description</Label>
                      <Textarea id="feature2Description" value={feature2Description} onChange={(e) => setFeature2Description(e.target.value)} rows={2} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                    </div>
                    <div className="p-4 border rounded-md space-y-2 bg-muted/20">
                      <Label htmlFor="feature3Title" className="font-semibold">Feature 3 Title</Label>
                      <Input id="feature3Title" value={feature3Title} onChange={(e) => setFeature3Title(e.target.value)} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                      <Label htmlFor="feature3Description" className="font-semibold">Feature 3 Description</Label>
                      <Textarea id="feature3Description" value={feature3Description} onChange={(e) => setFeature3Description(e.target.value)} rows={2} disabled={isSavingHomepageContent} className="mt-1 bg-background" />
                    </div>
                    <Button onClick={handleSaveHomepageContent} disabled={isSavingHomepageContent} className="w-full mt-4">
                      {isSavingHomepageContent ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="mr-2 h-4 w-4" /> Save Homepage Content</>}
                    </Button>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="policy-pages-content">
                   <AccordionTrigger className="text-lg hover:no-underline">
                     <div className="flex items-center">
                        <FileText className="mr-3 h-5 w-5 text-primary" /> Policy Pages Content
                     </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-6 pt-4">
                    <div>
                      <Label htmlFor="termsAndConditionsHTML">Terms &amp; Conditions HTML Content</Label>
                      <Textarea
                        id="termsAndConditionsHTML"
                        placeholder="Enter the full HTML content for the Terms and Conditions page..."
                        value={termsAndConditionsHTML}
                        onChange={(e) => setTermsAndConditionsHTML(e.target.value)}
                        rows={10}
                        disabled={isSavingPolicyPages}
                        className="mt-1 font-mono text-xs"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Enter valid HTML for the content area of the T&C page.</p>
                    </div>
                    <div>
                      <Label htmlFor="privacyPolicyHTML">Privacy Policy HTML Content</Label>
                      <Textarea
                        id="privacyPolicyHTML"
                        placeholder="Enter the full HTML content for the Privacy Policy page..."
                        value={privacyPolicyHTML}
                        onChange={(e) => setPrivacyPolicyHTML(e.target.value)}
                        rows={10}
                        disabled={isSavingPolicyPages}
                        className="mt-1 font-mono text-xs"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Enter valid HTML for the content area of the Privacy Policy page.</p>
                    </div>
                    <Button onClick={handleSavePolicyPages} disabled={isSavingPolicyPages} className="w-full mt-4">
                      {isSavingPolicyPages ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="mr-2 h-4 w-4" /> Save Policy Pages</>}
                    </Button>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

    
