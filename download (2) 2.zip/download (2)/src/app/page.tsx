
import RoomSelectionForm from '@/components/RoomSelectionForm';
import UserProfileDisplay from '@/components/UserProfileDisplay'; // Import the new component
import Image from 'next/image';
import { Zap, Sparkles, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default async function HomePage() {
  // Static content defined directly
  const content = {
    homepageHeroTitle: "Welcome to ChatterBox Rooms",
    tagline: "Connect, collaborate, and chat in real-time. Your display name will be set when you join a room.",
    homepageFeatureSectionTitle: "Why ChatterBox?",
    homepageBannerUrl: "https://placehold.co/800x300.png",
    homepageBannerAltText: "Chat application banner with diverse people collaborating",
    feature1Title: "Instant Rooms",
    feature1Description: "Generate unique room names or create your own in seconds. No sign-ups, just chat.",
    feature2Title: "AI-Powered Suggestions",
    feature2Description: "Never run out of things to say with intelligent reply suggestions to keep the conversation flowing.",
    feature3Title: "Group Chat Made Easy",
    feature3Description: "Simple and intuitive interface for group conversations, supporting up to 10 users per room.",
  };

  return (
    <div className="flex flex-col items-center justify-start min-h-[calc(100vh-160px)] py-8 px-4">
      <section className="w-full max-w-4xl text-center mb-10">
        <Image
          src={content.homepageBannerUrl}
          alt={content.homepageBannerAltText}
          width={800}
          height={300}
          className="rounded-lg shadow-xl mx-auto mb-8 object-cover"
          data-ai-hint="digital network"
          priority
        />
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-primary">
          {content.homepageHeroTitle}
        </h1>
        <p className="mt-6 text-md sm:text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          {content.tagline}
        </p>
      </section>

      {/* User Profile Display Section */}
      <section className="w-full max-w-md mt-4 mb-8">
        <UserProfileDisplay />
      </section>

      <section className="w-full max-w-md mt-4 mb-16">
        <RoomSelectionForm />
      </section>

      <section className="w-full max-w-5xl text-center">
        <h2 className="text-3xl font-semibold mb-10 text-foreground">
          {content.homepageFeatureSectionTitle}
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="items-center">
              <div className="p-3 rounded-full bg-accent/10 mb-3">
                <Zap className="h-10 w-10 text-accent" />
              </div>
              <CardTitle className="text-xl text-primary">{content.feature1Title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                {content.feature1Description}
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="items-center">
              <div className="p-3 rounded-full bg-accent/10 mb-3">
                <Sparkles className="h-10 w-10 text-accent" />
              </div>
              <CardTitle className="text-xl text-primary">{content.feature2Title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                {content.feature2Description}
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="items-center">
               <div className="p-3 rounded-full bg-accent/10 mb-3">
                <Users className="h-10 w-10 text-accent" />
              </div>
              <CardTitle className="text-xl text-primary">{content.feature3Title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                {content.feature3Description}
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
