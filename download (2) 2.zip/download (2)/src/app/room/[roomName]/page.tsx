
import ChatInterface from '@/components/chat/ChatInterface';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';
import type { RetentionPolicy, RoomMode } from '@/types';

interface RoomPageProps {
  params: {
    roomName: string;
  };
  searchParams: {
    password?: string;
    retention?: string; // RetentionPolicy values
    mode?: string; // RoomMode values
    maxUsers?: string; // Max users as string
  };
}

const DEFAULT_MAX_USERS_FALLBACK = 10;

export default function RoomPage({ params, searchParams }: RoomPageProps) {
  const decodedRoomName = decodeURIComponent(params.roomName);
  const password = searchParams?.password ? decodeURIComponent(searchParams.password) : undefined;
  const retention = searchParams?.retention ? decodeURIComponent(searchParams.retention) as RetentionPolicy : 'none';
  const mode = searchParams?.mode ? decodeURIComponent(searchParams.mode) as RoomMode : 'public';
  
  let maxUsersNum = DEFAULT_MAX_USERS_FALLBACK;
  if (searchParams?.maxUsers) {
    const parsedMaxUsers = parseInt(decodeURIComponent(searchParams.maxUsers), 10);
    if (!isNaN(parsedMaxUsers) && parsedMaxUsers >= 1 && parsedMaxUsers <= 1000) {
      maxUsersNum = parsedMaxUsers;
    }
  }


  if (!decodedRoomName) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="w-full max-w-md p-6 text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center text-destructive">
              <AlertTriangle className="mr-2" /> Invalid Room
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>The room name is missing or invalid. Please try joining a room again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] md:h-[calc(100vh-150px)]">
      <ChatInterface 
        roomName={decodedRoomName} 
        password={password} 
        initialRetentionPolicy={retention}
        initialRoomMode={mode}
        initialMaxUsers={maxUsersNum}
      />
    </div>
  );
}
