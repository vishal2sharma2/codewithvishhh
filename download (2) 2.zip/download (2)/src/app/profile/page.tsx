
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { UserCircle, Save, LogOut } from 'lucide-react';
import { useRouter } from 'next/navigation';

const NAME_KEY = 'chatterboxDisplayName';
const AGE_KEY = 'chatterboxUserAge';
const CITY_KEY = 'chatterboxUserCity';

export default function ProfilePage() {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [city, setCity] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    const savedName = localStorage.getItem(NAME_KEY);
    const savedAge = localStorage.getItem(AGE_KEY);
    const savedCity = localStorage.getItem(CITY_KEY);

    if (savedName) setName(savedName);
    if (savedAge) setAge(savedAge);
    if (savedCity) setCity(savedCity);
    setIsLoading(false);
  }, []);

  const handleSaveProfile = () => {
    if (!name.trim()) {
      toast({
        title: 'Validation Error',
        description: 'Name cannot be empty.',
        variant: 'destructive',
      });
      return;
    }
    localStorage.setItem(NAME_KEY, name.trim());
    localStorage.setItem(AGE_KEY, age.trim());
    localStorage.setItem(CITY_KEY, city.trim());
    toast({
      title: 'Profile Saved!',
      description: 'Your profile information has been updated.',
    });
  };

  const handleLogout = () => {
    localStorage.removeItem(NAME_KEY);
    localStorage.removeItem(AGE_KEY);
    localStorage.removeItem(CITY_KEY);
    setName('');
    setAge('');
    setCity('');
    toast({
      title: 'Logged Out',
      description: 'Your profile information has been cleared.',
    });
    router.push('/'); // Redirect to homepage after logout
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
        <p>Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 flex flex-col items-center">
      <Card className="w-full max-w-lg shadow-xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <UserCircle className="h-16 w-16 text-primary" />
          </div>
          <CardTitle className="text-3xl text-primary">Your Profile</CardTitle>
          <CardDescription>Update your personal information. This will be stored in your browser.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="age">Age</Label>
            <Input
              id="age"
              type="number"
              placeholder="Enter your age (optional)"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              placeholder="Enter your city (optional)"
              value={city}
              onChange={(e) => setCity(e.target.value)}
            />
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-3">
          <Button onClick={handleSaveProfile} className="w-full">
            <Save className="mr-2 h-4 w-4" /> Save Profile
          </Button>
          <Button onClick={handleLogout} variant="outline" className="w-full">
            <LogOut className="mr-2 h-4 w-4" /> Logout (Clear Profile)
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
