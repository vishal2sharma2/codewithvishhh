
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck } from 'lucide-react';

async function getPrivacyPolicyContent() {
  const defaultContent = "<p>Default Privacy Policy. Please update from the admin panel.</p>";
  try {
    // Use NEXT_PUBLIC_APP_URL if available, otherwise fallback to localhost for dev
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:9002';
    const res = await fetch(`${baseUrl}/api/admin/homepage-settings`, {
      cache: 'no-store', 
    });
    if (!res.ok) {
      console.error('Failed to fetch privacy policy content, status:', res.status);
      return defaultContent;
    }
    const data = await res.json();
    return data.privacyPolicyHTML || defaultContent;
  } catch (error) {
    console.error('Error fetching privacy policy content:', error);
    return defaultContent;
  }
}

export default async function PrivacyPolicyPage() {
  const privacyPolicyContent = await getPrivacyPolicyContent();

  return (
    <div className="container mx-auto py-8 px-4 max-w-3xl">
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <ShieldCheck className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-3xl text-primary">Privacy Policy</CardTitle>
        </CardHeader>
        <CardContent 
          className="prose prose-sm sm:prose lg:prose-lg xl:prose-xl mx-auto"
          dangerouslySetInnerHTML={{ __html: privacyPolicyContent }}
        />
      </Card>
    </div>
  );
}

    