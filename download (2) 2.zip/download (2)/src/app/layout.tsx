
import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import AppHeader from '@/components/layout/AppHeader';
import AppFooter from '@/components/layout/AppFooter';
import ThemeApplicator from '@/components/layout/ThemeApplicator';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

// Helper function to fetch global settings
async function getGlobalSettings() {
  const defaultSettings = {
    websiteName: "ChatterBox Rooms",
    tagline: "Connect, collaborate, and chat in real-time.",
    footerText: `© ${new Date().getFullYear()} ChatterBox Rooms. All rights reserved.`,
    instagramUrl: "",
    linkedinUrl: "",
    youtubeUrl: "",
  };
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:9002'}/api/admin/homepage-settings`, {
      cache: 'no-store', 
    });
    if (!res.ok) {
      console.error('Failed to fetch global settings for layout, status:', res.status);
      return defaultSettings;
    }
    const data = await res.json();
    return {
      websiteName: data.websiteName || defaultSettings.websiteName,
      tagline: data.tagline || defaultSettings.tagline, // Used for metadata
      footerText: data.footerText || defaultSettings.footerText,
      instagramUrl: data.instagramUrl || defaultSettings.instagramUrl,
      linkedinUrl: data.linkedinUrl || defaultSettings.linkedinUrl,
      youtubeUrl: data.youtubeUrl || defaultSettings.youtubeUrl,
    };
  } catch (error) {
    console.error('Error fetching global settings for layout:', error);
    return defaultSettings;
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getGlobalSettings();
  return {
    title: settings.websiteName,
    description: settings.tagline,
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = await getGlobalSettings();

  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased flex flex-col min-h-screen`}
      >
        <ThemeApplicator />
        <AppHeader 
          websiteName={settings.websiteName} 
          instagramUrl={settings.instagramUrl}
          linkedinUrl={settings.linkedinUrl}
          youtubeUrl={settings.youtubeUrl}
        />
        <main className="flex-grow container mx-auto p-4 sm:p-6 md:p-8">
          {children}
        </main>
        <AppFooter footerText={settings.footerText} />
        <Toaster />
      </body>
    </html>
  );
}

    