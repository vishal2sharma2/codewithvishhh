
'use client';

import { useEffect, useState, useRef } from 'react';
import type { Socket as ClientSocket } from 'socket.io-client';
import { io } from 'socket.io-client';
import type { JoinRoomPayload, RetentionPolicy, RoomMode } from '@/types';

export const useSocket = (
  roomName?: string,
  userName?: string,
  userAge?: string, // Added
  userCity?: string, // Added
  password?: string,
  retentionPolicy?: RetentionPolicy,
  roomMode?: RoomMode,
  maxUsers?: number
) => {
  const socketRef = useRef<ClientSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    if (!roomName || !userName) { // userName is now crucial for payload
      if (socketRef.current) {
        console.log('[useSocket] roomName or userName is invalid. Disconnecting existing socket.');
        socketRef.current.disconnect();
        socketRef.current = null;
        setIsConnected(false);
      }
      return; 
    }

    if (socketRef.current) {
      console.log('[useSocket] Dependencies changed or re-evaluating. Disconnecting old socket before new attempt.');
      socketRef.current.disconnect();
      socketRef.current = null;
      setIsConnected(false);
    }

    console.log(`[useSocket] Attempting to connect for room: "${roomName}", user: "${userName}", age: "${userAge}", city: "${userCity}", maxUsers: ${maxUsers}`);
    fetch('/api/socket')
      .then((res) => {
        if (!res.ok) throw new Error('Failed to initialize socket API route');
        console.log('[useSocket] Socket API route pinged successfully.');

        const newSocket = io({
          path: '/api/socket_io',
          addTrailingSlash: false,
        });
        socketRef.current = newSocket;

        newSocket.on('connect', () => {
          console.log('[useSocket] Socket connected:', newSocket.id);
          setIsConnected(true);
          const payload: JoinRoomPayload = {
            roomName,
            userName,
            userAge, // Add age to payload
            userCity, // Add city to payload
            retentionPolicy: retentionPolicy || 'none',
            roomMode: roomMode || 'public',
            maxUsers: maxUsers || 10,
          };
          if (password) {
            payload.password = password;
          }
          console.log('[useSocket] Emitting join-room with payload:', payload);
          newSocket.emit('join-room', payload);
        });

        newSocket.on('disconnect', (reason: string) => {
          console.log('[useSocket] Socket disconnected:', reason);
          setIsConnected(false);
        });

        newSocket.on('connect_error', (error: Error) => {
          console.error('[useSocket] Socket connection error:', error);
          setIsConnected(false);
          if (socketRef.current) {
            socketRef.current.disconnect(); 
            socketRef.current = null;
          }
        });
      })
      .catch(error => {
        console.error('[useSocket] Error pinging socket API route:', error);
      });

    return () => {
      if (socketRef.current) {
        console.log(`[useSocket] Cleanup: Disconnecting socket for room: "${roomName}", user: "${userName}" (Socket ID: ${socketRef.current.id})`);
        socketRef.current.disconnect();
        socketRef.current = null; 
        setIsConnected(false); 
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roomName, userName, userAge, userCity, password, retentionPolicy, roomMode, maxUsers]); // Added userAge, userCity to dependencies

  return { socket: socketRef.current, isConnected };
};
