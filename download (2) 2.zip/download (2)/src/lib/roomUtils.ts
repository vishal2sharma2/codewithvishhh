import { v4 as uuidv4 } from 'uuid';

const adjectives = ["Quick", "Lazy", "Sleepy", "Happy", "Red", "Blue", "Green", "Silent", "Chatty", "Clever"];
const nouns = ["Fox", "Dog", "Cat", "Mouse", "House", "Room", "Zone", "Place", "Space", "Den"];

export function generateReadableRoomName(): string {
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const num = Math.floor(Math.random() * 1000);
  return `${adj}-${noun}-${num}`;
}

export function generateUUIDRoomName(): string {
  return uuidv4().slice(0, 13); // Short UUID
}
