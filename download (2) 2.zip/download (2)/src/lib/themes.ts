
export interface ThemeColors {
  '--background': string;
  '--foreground': string;
  '--card': string;
  '--card-foreground': string;
  '--popover': string;
  '--popover-foreground': string;
  '--primary': string;
  '--primary-foreground': string;
  '--secondary': string;
  '--secondary-foreground': string;
  '--muted': string;
  '--muted-foreground': string;
  '--accent': string;
  '--accent-foreground': string;
  '--border': string;
  '--input': string;
  '--ring': string;
}

export const themes: Record<string, ThemeColors> = {
  defaultLight: {
    '--background': '210 17% 96%', // #ecf0f1 Neutral Gray
    '--foreground': '210 20% 25%', // Darker text for contrast
    '--card': '0 0% 100%', // White
    '--card-foreground': '210 20% 25%',
    '--popover': '0 0% 100%',
    '--popover-foreground': '210 20% 25%',
    '--primary': '204 70% 53%', // #3498db Calm Blue
    '--primary-foreground': '210 40% 98%', // Light text on blue
    '--secondary': '210 17% 90%', // Slightly darker gray for secondary elements
    '--secondary-foreground': '210 20% 25%',
    '--muted': '210 17% 85%', // Muted gray
    '--muted-foreground': '210 15% 50%', // Muted text
    '--accent': '145 63% 49%', // #2ecc71 Vibrant Green
    '--accent-foreground': '0 0% 100%', // White text on green
    '--border': '210 17% 88%',
    '--input': '0 0% 100%', // White input background
    '--ring': '204 70% 53%',
  },
  deepOceanDark: {
    '--background': '220 30% 10%', // Very dark blue
    '--foreground': '210 25% 88%', // Light grayish blue
    '--card': '220 30% 15%', // Dark blue card
    '--card-foreground': '210 25% 88%',
    '--popover': '220 30% 15%',
    '--popover-foreground': '210 25% 88%',
    '--primary': '180 70% 45%', // Teal
    '--primary-foreground': '220 30% 95%', // Very light for primary
    '--secondary': '220 30% 20%', // Slightly lighter dark blue
    '--secondary-foreground': '210 25% 80%',
    '--muted': '220 30% 25%',
    '--muted-foreground': '210 20% 60%',
    '--accent': '45 90% 55%', // Bright Yellow/Gold
    '--accent-foreground': '220 30% 5%', // Dark for accent
    '--border': '220 30% 30%',
    '--input': '220 30% 22%',
    '--ring': '180 70% 45%',
  },
  forestCalm: {
    '--background': '120 10% 92%', // Very light green-gray
    '--foreground': '100 25% 20%', // Dark forest green
    '--card': '90 15% 98%', // Off-white with a hint of green
    '--card-foreground': '100 25% 20%',
    '--popover': '90 15% 98%',
    '--popover-foreground': '100 25% 20%',
    '--primary': '130 40% 40%', // Muted forest green
    '--primary-foreground': '90 40% 95%', // Light cream for primary
    '--secondary': '100 10% 85%', // Light moss green
    '--secondary-foreground': '100 25% 25%',
    '--muted': '90 10% 80%',
    '--muted-foreground': '100 15% 45%',
    '--accent': '35 60% 50%', // Earthy orange/brown
    '--accent-foreground': '0 0% 100%',
    '--border': '100 10% 80%',
    '--input': '90 15% 96%',
    '--ring': '130 40% 40%',
  },
};

export const DEFAULT_THEME_NAME = 'defaultLight';
