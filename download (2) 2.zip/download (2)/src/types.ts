
export type RetentionPolicy = '24h' | '48h' | '3d' | '7d' | '30d' | 'none';
export type RoomMode = 'public' | 'personal';

// Represents user profile information that can be stored/transmitted
export interface UserProfile {
  id: string; // socketId
  name: string;
  age?: string; // Optional
  city?: string; // Optional
}

export interface Message {
  id: string;
  userName: string; // Name of the user who sent the message
  text?: string;
  timestamp: string;
  type: 'user' | 'notification' | 'image' | 'video' | 'admin_announcement';
  isSender?: boolean;
  socketId?: string; // socketId of the sender
  mediaUrl?: string;
  fileName?: string;
}

export interface JoinRoomPayload {
  roomName: string;
  userName: string; // This is the display name
  userAge?: string; // Added
  userCity?: string; // Added
  password?: string;
  retentionPolicy?: RetentionPolicy;
  roomMode?: RoomMode;
  maxUsers?: number;
}

// For server-side use in socket.ts
export interface RoomData {
  users: Map<string, UserProfile>; // socketId -> UserProfile
  messages: Message[];
  retentionPolicy: RetentionPolicy;
  password?: string;
  roomMode: RoomMode;
  maxUsers: number;
}

// For reported messages
export interface ReportedMessageInfo {
  reportId: string;
  message: Message;
  roomName: string;
  reporterSocketId: string | null;
  reportedAt: string;
}

// For updating room settings from admin
export interface UpdateRoomSettingsPayload {
  roomName: string;
  password?: string | null;
  retentionPolicy?: RetentionPolicy;
  maxUsers?: number;
}

export interface RoomSettingsUpdateNotification {
  retentionPolicy?: RetentionPolicy;
  maxUsers?: number;
  passwordChanged?: boolean;
}

// For admin panel display of connected users
export interface ConnectedUserInfoForAdmin extends UserProfile { // Renamed from ConnectedUserInfo
  roomName: string;
}
