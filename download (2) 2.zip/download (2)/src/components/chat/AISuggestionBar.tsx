import { Button } from '@/components/ui/button';
import { Sparkles } from 'lucide-react';

interface AISuggestionBarProps {
  suggestions: string[];
  onSuggestionClick: (suggestion: string) => void;
  isLoading: boolean;
}

export default function AISuggestionBar({ suggestions, onSuggestionClick, isLoading }: AISuggestionBarProps) {
  if (isLoading) {
    return (
      <div className="p-2 text-sm text-muted-foreground flex items-center justify-center">
        <Sparkles className="mr-2 h-4 w-4 animate-pulse text-primary" />
        Generating suggestions...
      </div>
    );
  }

  if (!suggestions || suggestions.length === 0) {
    return null;
  }

  return (
    <div className="p-2 border-t bg-background">
      <div className="flex items-center mb-2">
         <Sparkles className="mr-2 h-4 w-4 text-primary" />
         <p className="text-sm font-medium text-primary">AI Suggestions:</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {suggestions.map((suggestion, index) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            onClick={() => onSuggestionClick(suggestion)}
            className="text-xs shadow-sm hover:bg-accent/10 hover:border-accent"
          >
            {suggestion}
          </Button>
        ))}
      </div>
    </div>
  );
}
