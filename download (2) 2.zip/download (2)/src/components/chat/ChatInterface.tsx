
'use client';

import { useState, useEffect, useRef, FormEvent, ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Send, LogIn, Users, LogOut, Loader2, AlertCircle, MessageSquareDashed, Share2, AlertTriangle, ShieldAlert, Clock, Paperclip, Megaphone, UserX, KeyRound, Info } from 'lucide-react';
import { useSocket } from '@/hooks/useSocket';
import type { Message, UserProfile, RetentionPolicy, JoinRoomPayload, RoomMode, RoomSettingsUpdateNotification } from '@/types';
import MessageBubble from './MessageBubble';
import AISuggestionBar from './AISuggestionBar';
import { suggestReplies, SuggestRepliesInput } from '@/ai/flows/suggest-replies';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface ChatInterfaceProps {
  roomName: string;
  password?: string;
  initialRetentionPolicy: RetentionPolicy;
  initialRoomMode: RoomMode;
  initialMaxUsers: number;
}

const MAX_FILE_SIZE_MB = 5;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const DISPLAY_NAME_LOCAL_STORAGE_KEY = 'chatterboxDisplayName';
const AGE_LOCAL_STORAGE_KEY = 'chatterboxUserAge';
const CITY_LOCAL_STORAGE_KEY = 'chatterboxUserCity';

export default function ChatInterface({ roomName, password, initialRetentionPolicy, initialRoomMode, initialMaxUsers }: ChatInterfaceProps) {
  const [currentUserName, setCurrentUserName] = useState<string | null>(null); // Renamed from userName to currentUserName for clarity
  const [currentUserAge, setCurrentUserAge] = useState<string | undefined>(undefined);
  const [currentUserCity, setCurrentUserCity] = useState<string | undefined>(undefined);

  const [isLoadingName, setIsLoadingName] = useState<boolean>(true);
  const [nameInput, setNameInput] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [usersInRoom, setUsersInRoom] = useState<UserProfile[]>([]); // Changed UserType to UserProfile
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [isAISuggesting, setIsAISuggesting] = useState(false);
  const [showRoomFullAlert, setShowRoomFullAlert] = useState(false);
  const [roomFullMessage, setRoomFullMessage] = useState('');
  const [showAuthFailedAlert, setShowAuthFailedAlert] = useState(false);
  const [showRoomClosedAlert, setShowRoomClosedAlert] = useState(false);
  const [roomClosedMessage, setRoomClosedMessage] = useState('');
  const [showKickedAlert, setShowKickedAlert] = useState(false);
  const [kickedMessage, setKickedMessage] = useState('');
  const [currentRetentionPolicy, setCurrentRetentionPolicy] = useState<RetentionPolicy>(initialRetentionPolicy);
  const [currentRoomMode, setCurrentRoomMode] = useState<RoomMode>(initialRoomMode);
  const [currentMaxUsers, setCurrentMaxUsers] = useState<number>(initialMaxUsers);
  const [isRoomPasswordProtected, setIsRoomPasswordProtected] = useState<boolean>(!!password);


  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    console.log('[ChatInterface] useEffect for name loading triggered.');
    const savedName = localStorage.getItem(DISPLAY_NAME_LOCAL_STORAGE_KEY);
    const savedAge = localStorage.getItem(AGE_LOCAL_STORAGE_KEY);
    const savedCity = localStorage.getItem(CITY_LOCAL_STORAGE_KEY);

    if (savedName) {
      console.log(`[ChatInterface] Found saved name in localStorage: "${savedName}"`);
      setNameInput(savedName); // Pre-fill the input
    } else {
      console.log('[ChatInterface] No saved name in localStorage.');
      setNameInput('');
    }
    // Age and city are not directly pre-filled in the name input but will be sent on join
    if (savedAge) setCurrentUserAge(savedAge);
    if (savedCity) setCurrentUserCity(savedCity);

    setIsLoadingName(false);
    console.log('[ChatInterface] Finished name loading. isLoadingName:', false, 'nameInput pre-filled with:', savedName || "''");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const { socket, isConnected } = useSocket(
    !isLoadingName && currentUserName ? roomName : undefined, // Only pass roomName if currentUserName is also set
    !isLoadingName ? currentUserName : undefined,
    !isLoadingName && currentUserName ? currentUserAge : undefined, // Pass age
    !isLoadingName && currentUserName ? currentUserCity : undefined, // Pass city
    password,
    currentRetentionPolicy,
    currentRoomMode,
    currentMaxUsers
  );

  useEffect(() => {
    if (!socket || !isConnected || !currentUserName) {
      console.log(`[ChatInterface] Socket event listeners setup skipped. Socket: ${!!socket}, Connected: ${isConnected}, UserName: ${currentUserName}`);
      return;
    }

    console.log(`[ChatInterface] Socket connected (${socket.id}), user: ${currentUserName}. Attaching event listeners for room: ${roomName}.`);

    socket.on('initial-messages', (data: { messages: Message[], retentionPolicy: RetentionPolicy, roomMode: RoomMode, maxUsers: number, isPasswordProtected?: boolean }) => {
      console.log('[ChatInterface] Received initial-messages:', data);
      setMessages(data.messages.map(msg => ({...msg, isSender: msg.socketId === socket.id })));
      setCurrentRetentionPolicy(data.retentionPolicy);
      setCurrentRoomMode(data.roomMode);
      setCurrentMaxUsers(data.maxUsers);
      setIsRoomPasswordProtected(!!data.isPasswordProtected);
    });

    socket.on('receive-message', (newMessage: Message) => {
      console.log('[ChatInterface] Received receive-message:', newMessage);
      setMessages((prevMessages) => [...prevMessages, { ...newMessage, isSender: newMessage.socketId === socket.id }]);
    });

    socket.on('user-joined', (user: UserProfile) => { // Changed UserType to UserProfile
       console.log('[ChatInterface] Received user-joined:', user);
      toast({
        title: "User Joined",
        description: `${user.name || 'Someone'} has joined the room.`,
        variant: "default",
      });
    });

    socket.on('user-left', (user: UserProfile) => { // Changed UserType to UserProfile
      console.log('[ChatInterface] Received user-left:', user);
      toast({
        title: "User Left",
        description: `${user.name || 'Someone'} has left the room.`,
        variant: "default",
      });
    });

    socket.on('current-users', (currentUsers: UserProfile[]) => { // Changed UserType to UserProfile
      console.log('[ChatInterface] Received current-users:', currentUsers);
      setUsersInRoom(currentUsers);
    });

    socket.on('room-full', ({ roomName: fullRoomName, maxUsers }: { roomName: string, maxUsers: number }) => {
      console.log(`[ChatInterface] Received room-full for: ${fullRoomName}, max users: ${maxUsers}`);
      if (roomName === fullRoomName && (!socket || !usersInRoom.find(u => u.id === socket.id))) {
        setRoomFullMessage(`The chat room "${roomName}" is currently full (max ${maxUsers} users). Please try joining another room or come back later.`);
        setShowRoomFullAlert(true);
      }
    });

    socket.on('auth-failed', () => {
      console.log('[ChatInterface] Received auth-failed.');
      setShowAuthFailedAlert(true);
    });

    socket.on('room-closed', (data: { roomName: string; message: string }) => {
      console.log('[ChatInterface] Received room-closed:', data);
      if (data.roomName === roomName) {
        setRoomClosedMessage(data.message);
        setShowRoomClosedAlert(true);
        if(socket) socket.disconnect();
      }
    });

    socket.on('global-announcement', (announcementMessage: Message) => {
       console.log('[ChatInterface] Received global-announcement:', announcementMessage);
      setMessages((prevMessages) => [...prevMessages, announcementMessage]);
      toast({
        title: "Admin Announcement",
        description: announcementMessage.text || "New announcement received!",
        duration: 10000,
        className: "border-accent text-accent-foreground bg-accent/10",
        action: <Megaphone className="h-5 w-5 text-accent" />,
      });
    });

    socket.on('you-were-kicked', (data: { roomName: string; message: string }) => {
      console.log('[ChatInterface] Received you-were-kicked:', data);
      if (data.roomName === roomName) {
        setKickedMessage(data.message || `You have been kicked from room "${roomName}" by an administrator.`);
        setShowKickedAlert(true);
        if(socket) socket.disconnect();
      }
    });
    
    socket.on('room-settings-updated', (update: RoomSettingsUpdateNotification) => {
      console.log('[ChatInterface] Received room-settings-updated:', update);
      let toastDescription = "Room settings have been updated by an administrator.";
      const updatesApplied: string[] = [];

      if (update.retentionPolicy) {
        setCurrentRetentionPolicy(update.retentionPolicy);
        updatesApplied.push(`Retention: ${getRetentionPolicyText(update.retentionPolicy)}`);
      }
      if (update.maxUsers) {
        setCurrentMaxUsers(update.maxUsers);
        updatesApplied.push(`Max Users: ${update.maxUsers}`);
      }
      if (update.passwordChanged !== undefined) {
         setIsRoomPasswordProtected(update.passwordChanged ? true : false); 
         updatesApplied.push(update.passwordChanged ? "Password status changed" : "Password status changed (now public or new password set)");
      }
      
      if (updatesApplied.length > 0) {
        toastDescription = `Room settings updated: ${updatesApplied.join(', ')}.`;
      }

      toast({
        title: "Room Settings Changed",
        description: toastDescription,
        action: <Info className="h-5 w-5 text-blue-500" />,
      });
    });


    return () => {
      console.log(`[ChatInterface] Cleaning up socket listeners for room: ${roomName}, user: ${currentUserName}, socketId: ${socket?.id}`);
      socket.off('initial-messages');
      socket.off('receive-message');
      socket.off('user-joined');
      socket.off('user-left');
      socket.off('current-users');
      socket.off('room-full');
      socket.off('auth-failed');
      socket.off('room-closed');
      socket.off('global-announcement');
      socket.off('you-were-kicked');
      socket.off('room-settings-updated');
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket, isConnected, currentUserName, roomName]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (messages.length > 0 && currentUserName && isConnected) {
      const fetchSuggestions = async () => {
        setIsAISuggesting(true);
        const chatHistory = messages
          .map(msg => {
            if (msg.type === 'user' && msg.text) return `${msg.userName}: ${msg.text}`;
            if (msg.type === 'image') return `${msg.userName}: [sent an image: ${msg.fileName || 'image'}]`;
            if (msg.type === 'video') return `${msg.userName}: [sent a video: ${msg.fileName || 'video'}]`;
            if (msg.type === 'admin_announcement' && msg.text) return `Admin: ${msg.text}`;
            return null;
          })
          .filter(Boolean)
          .join('\n');

        if (chatHistory.trim() === "") {
          setIsAISuggesting(false);
          setAiSuggestions([]);
          return;
        }

        try {
          const input: SuggestRepliesInput = { chatHistory };
          const result = await suggestReplies(input);
          setAiSuggestions(result.suggestions);
        } catch (error) {
          console.error('Error fetching AI suggestions:', error);
          setAiSuggestions([]);
        } finally {
          setIsAISuggesting(false);
        }
      };
      const timer = setTimeout(fetchSuggestions, 1000);
      return () => clearTimeout(timer);
    } else {
      setAiSuggestions([]);
    }
  }, [messages, currentUserName, isConnected]);

  const handleNameSubmit = (e: FormEvent) => {
    e.preventDefault();
    console.log('[ChatInterface] handleNameSubmit called. nameInput:', nameInput);
    if (nameInput.trim()) {
      const trimmedName = nameInput.trim();
      setCurrentUserName(trimmedName); // Set currentUserName
      localStorage.setItem(DISPLAY_NAME_LOCAL_STORAGE_KEY, trimmedName);
      
      // Fetch age and city from localStorage again to ensure they are current when joining
      const age = localStorage.getItem(AGE_LOCAL_STORAGE_KEY);
      const city = localStorage.getItem(CITY_LOCAL_STORAGE_KEY);
      if (age) setCurrentUserAge(age);
      if (city) setCurrentUserCity(city);

      console.log(`[ChatInterface] Display name set to: "${trimmedName}". Age: ${age || 'N/A'}, City: ${city || 'N/A'}. This should trigger useSocket useEffect.`);
    } else {
      console.log('[ChatInterface] Name input was empty.');
      toast({
        title: 'Error',
        description: 'Display name cannot be empty.',
        variant: 'destructive',
      });
    }
  };

  const handleSendMessage = (e?: FormEvent) => {
    e?.preventDefault();
    if (currentMessage.trim() && socket && currentUserName && isConnected) {
      socket.emit('send-message', { roomName, message: currentMessage, userName: currentUserName });
      setCurrentMessage('');
      setAiSuggestions([]);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setCurrentMessage(suggestion);
  };

  const handleShareRoom = async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: 'Link Copied!',
        description: 'Room link copied to clipboard.',
      });
    } catch (err) {
      console.error('Failed to copy link: ', err);
      toast({
        title: 'Error',
        description: 'Could not copy link to clipboard.',
        variant: 'destructive',
      });
    }
  };

  const handleLeaveRoom = () => {
    if (socket) {
      console.log(`[ChatInterface] User ${currentUserName} leaving room. Disconnecting socket ${socket.id}`);
      socket.disconnect();
    }
    setCurrentUserName(null); // Reset userName to force name input on next join attempt.
    router.push('/');
  };

  const getRetentionPolicyText = (policy: RetentionPolicy) => {
    switch (policy) {
      case '24h': return '24 Hours';
      case '48h': return '48 Hours';
      case '3d': return '3 Days';
      case '7d': return '7 Days';
      case '30d': return '30 Days';
      case 'none':
      default: return 'Permanent';
    }
  };

  const getRoomModeText = (mode: RoomMode) => {
    switch (mode) {
      case 'personal': return 'Personal Room';
      case 'public':
      default: return 'Public Room';
    }
  };

  const handleFileSelect = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !socket || !currentUserName || !isConnected) return;

    if (file.size > MAX_FILE_SIZE_BYTES) {
        toast({
            title: "File Too Large",
            description: `Please select a file smaller than ${MAX_FILE_SIZE_MB}MB.`,
            variant: "destructive",
        });
        if(fileInputRef.current) fileInputRef.current.value = "";
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const mediaUrl = e.target?.result;
      if (typeof mediaUrl !== 'string' || !mediaUrl.startsWith('data:')) {
          toast({
              title: "File Read Error",
              description: "Could not properly read the file content as a valid Data URI.",
              variant: "destructive",
          });
          if(fileInputRef.current) fileInputRef.current.value = "";
          return;
      }

      let fileType: 'image' | 'video';
      if (file.type.startsWith('image/')) {
        fileType = 'image';
      } else if (file.type.startsWith('video/')) {
        fileType = 'video';
      } else {
        toast({
          title: "Unsupported File Type",
          description: "Please select an image or video file.",
          variant: "destructive",
        });
        if(fileInputRef.current) fileInputRef.current.value = "";
        return;
      }

      socket.emit('send-media-message', {
        roomName,
        userName: currentUserName,
        mediaUrl,
        fileType,
        fileName: file.name,
      });
      if(fileInputRef.current) fileInputRef.current.value = "";
    };
    reader.onerror = () => {
        toast({
            title: "File Read Error",
            description: "Could not read the selected file. Please try again.",
            variant: "destructive",
        });
        if(fileInputRef.current) fileInputRef.current.value = "";
    };
    reader.readAsDataURL(file);
  };


  if (showRoomFullAlert) {
    return (
      <AlertDialog open={showRoomFullAlert} onOpenChange={() => router.push('/')}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <AlertTriangle className="mr-2 text-destructive" /> Room Full
            </AlertDialogTitle>
            <AlertDialogDescription>
              {roomFullMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => router.push('/')}>
              Back to Home
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  if (showAuthFailedAlert) {
    return (
      <AlertDialog open={showAuthFailedAlert} onOpenChange={() => router.push('/')}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <ShieldAlert className="mr-2 text-destructive" /> Authentication Failed
            </AlertDialogTitle>
            <AlertDialogDescription>
              The password provided was incorrect, or this room is private and requires a password. Please try again or return to the homepage.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => router.push('/')}>
              Back to Home
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  if (showRoomClosedAlert) {
    return (
      <AlertDialog open={showRoomClosedAlert} onOpenChange={() => router.push('/')}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <AlertCircle className="mr-2 text-orange-500" /> Room Closed
            </AlertDialogTitle>
            <AlertDialogDescription>
              {roomClosedMessage || `The chat room "${roomName}" has been closed.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => router.push('/')}>
              Back to Home
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  if (showKickedAlert) {
    return (
      <AlertDialog open={showKickedAlert} onOpenChange={() => router.push('/')}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <UserX className="mr-2 text-orange-500" /> Kicked from Room
            </AlertDialogTitle>
            <AlertDialogDescription>
              {kickedMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => router.push('/')}>
              Back to Home
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  if (isLoadingName) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-4">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p>Loading user information...</p>
      </div>
    );
  }


  if (!currentUserName) {
    console.log(`[ChatInterface] Rendering name input form. isLoadingName: ${isLoadingName}, currentUserName: ${currentUserName}, nameInput value: ${nameInput}`);
    return (
      <div className="flex flex-col items-center justify-center h-full p-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-primary flex items-center">
              <LogIn className="mr-2" /> Join Room: {roomName}
            </CardTitle>
            <CardDescription>Please enter your display name to join the chat.</CardDescription>
          </CardHeader>
          <form onSubmit={handleNameSubmit}>
            <CardContent>
              <Input
                placeholder="Your Display Name"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                aria-label="Your Display Name"
                className="text-base"
                autoFocus
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={!nameInput.trim()}>
                Enter Chat
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    );
  }

  console.log(`[ChatInterface] Proceeding to socket connection check. UserName: ${currentUserName}, IsConnected: ${isConnected}, Socket: ${!!socket}`);

  if (currentUserName && !isConnected && !socket) {
    console.log(`[ChatInterface] Rendering loader for initial connection attempt. User: ${currentUserName}`);
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg">Connecting to {roomName} as {currentUserName}...</p>
      </div>
    );
  }

   if (currentUserName && !isConnected && socket) {
     console.log(`[ChatInterface] Rendering connection error message. User: ${currentUserName}`);
     return (
      <div className="flex flex-col items-center justify-center h-full text-destructive-foreground bg-destructive/10 p-4 rounded-lg">
        <AlertCircle className="h-12 w-12 mb-4 text-destructive" />
        <p className="text-lg font-semibold">Connection Error</p>
        <p className="text-sm text-center">Could not establish a connection to the chat server. <br/>Please check your internet connection and try refreshing the page.</p>
        <Button onClick={() => router.refresh()} className="mt-4">Refresh Page</Button>
      </div>
    );
  }


  return (
    <div className="flex flex-col md:flex-row h-full bg-card shadow-2xl rounded-lg overflow-hidden border">
      <aside className="w-full md:w-64 bg-secondary/50 border-b md:border-b-0 md:border-r p-4 hidden md:block">
        <div className="flex items-center mb-4">
          <Users className="mr-2 h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold text-primary">Users ({usersInRoom.length})</h2>
        </div>
        <ScrollArea className="h-32 md:h-[calc(100%-120px)]">
          <ul className="space-y-2">
            {usersInRoom.map((user) => (
              <li key={user.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-primary/10 transition-colors">
                <Avatar className="h-7 w-7 text-xs">
                   <AvatarFallback className={(user.name && user.name === currentUserName) ? "bg-accent text-accent-foreground" : "bg-primary/20 text-primary"}>
                    {user.name ? user.name.substring(0, 2).toUpperCase() : '??'}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm truncate">{user.name || 'Unknown User'}{(user.name && user.name === currentUserName) && " (You)"}</span>
              </li>
            ))}
          </ul>
        </ScrollArea>
      </aside>

      <main className="flex-1 flex flex-col">
        <header className="p-4 border-b bg-background shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-primary truncate">Room: {roomName}</h1>
              <div className="text-xs text-muted-foreground flex items-center flex-wrap gap-x-2 gap-y-1">
                <span>{getRoomModeText(currentRoomMode)}</span>
                {isRoomPasswordProtected && <span className="text-accent font-semibold flex items-center"><KeyRound className="h-3 w-3 mr-1" />Private</span>}
                <span>| Users: {usersInRoom.length}/{currentMaxUsers}</span>
                <span>| Connected as: {currentUserName}</span>
                {currentRetentionPolicy !== 'none' && (
                  <span className="flex items-center" title={`Messages older than ${getRetentionPolicyText(currentRetentionPolicy)} will be removed.`}>
                    <Clock className="h-3 w-3 mr-1 text-muted-foreground" />
                    {getRetentionPolicyText(currentRetentionPolicy)}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center">
              <Button
                onClick={handleShareRoom}
                variant="outline"
                size="icon"
                aria-label="Share room link"
                className="ml-2"
              >
                <Share2 className="h-5 w-5" />
              </Button>
              <Button
                onClick={handleLeaveRoom}
                variant="outline"
                size="icon"
                aria-label="Leave room"
                className="ml-2 text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/50 hover:border-destructive"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </header>

        <ScrollArea className="flex-1 p-4 space-y-4 bg-background/30">
          {messages.length === 0 && isConnected && (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground pt-10">
              <MessageSquareDashed size={48} className="mb-4" />
              <p className="text-lg">No messages yet.</p>
              <p className="text-sm">Be the first to say something!</p>
            </div>
          )}
          {messages.map((msg) => (
            <MessageBubble 
              key={msg.id} 
              message={{...msg, isSender: msg.socketId === socket?.id && (msg.type === 'user' || msg.type === 'image' || msg.type === 'video') }} 
              roomName={roomName}
              currentUserSocketId={socket?.id}
            />
          ))}
          <div ref={messagesEndRef} />
        </ScrollArea>

        {aiSuggestions.length > 0 && currentUserName && isConnected && (
          <AISuggestionBar
            suggestions={aiSuggestions}
            onSuggestionClick={handleSuggestionClick}
            isLoading={isAISuggesting}
          />
        )}

        <form onSubmit={handleSendMessage} className="p-4 border-t bg-background">
          <div className="flex items-center gap-2">
            <Input
              type="text"
              placeholder="Type your message..."
              value={currentMessage}
              onChange={(e) => setCurrentMessage(e.target.value)}
              className="flex-1 text-sm"
              aria-label="Chat message input"
              disabled={!isConnected || !currentUserName}
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
              accept="image/*,video/*"
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              disabled={!isConnected || !currentUserName}
              aria-label="Attach file"
            >
              <Paperclip className="h-5 w-5" />
            </Button>
            <Button type="submit" disabled={!currentMessage.trim() || !isConnected || !currentUserName} size="icon" aria-label="Send message">
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
}
