
'use client';

import type { Message } from '@/types';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Bot, Bell, Megaphone, MoreVertical, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import Image from 'next/image';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useToast } from '@/hooks/use-toast';

interface MessageBubbleProps {
  message: Message;
  roomName: string; // Added roomName
  currentUserSocketId: string | undefined; // Added currentUserSocketId
}

export default function MessageBubble({ message, roomName, currentUserSocketId }: MessageBubbleProps) {
  const { text, userName, timestamp, type, isSender, mediaUrl, fileName, id: messageId, socketId: messageSenderSocketId } = message;
  const { toast } = useToast();

  const getInitials = (name: string) => {
    if (!name) return '?';
    const parts = name.split(' ');
    if (parts.length > 1) {
      return parts[0][0].toUpperCase() + parts[1][0].toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const formattedTime = timestamp ? format(new Date(timestamp), 'p') : '';

  const handleReportMessage = async () => {
    console.log(`Reporting message ID: ${messageId} in room: ${roomName} by user: ${currentUserSocketId}`);
    if (!currentUserSocketId) {
        toast({
            title: "Cannot Report",
            description: "Your user identity is not available to submit a report.",
            variant: "destructive",
        });
        return;
    }
    try {
        const response = await fetch('/api/report-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message, // Send the whole message object
                roomName: roomName,
                reporterSocketId: currentUserSocketId,
            }),
        });
        if (response.ok) {
            toast({
                title: "Message Reported",
                description: "Thank you for your report. It has been submitted for review.",
                action: <AlertTriangle className="h-5 w-5 text-orange-500" />,
            });
        } else {
            const errorData = await response.json().catch(() => ({error: "Failed to submit report."}));
            toast({
                title: "Reporting Failed",
                description: errorData.error || "Could not submit your report. Please try again.",
                variant: "destructive",
            });
        }
    } catch (error) {
        console.error("Failed to submit report:", error);
        toast({
            title: "Reporting Error",
            description: "An unexpected error occurred while submitting your report.",
            variant: "destructive",
        });
    }
  };

  if (type === 'notification') {
    return (
      <div className="py-2 px-4 text-center">
        <span className="text-xs text-muted-foreground italic bg-secondary px-3 py-1 rounded-full shadow-sm">
          <Bell size={12} className="inline mr-1" />
          {text}
        </span>
      </div>
    );
  }

  if (type === 'admin_announcement') {
    return (
      <div className="py-3 px-4 my-2 text-center">
        <div className="inline-block bg-accent/10 border border-accent/30 text-accent-foreground p-3 rounded-lg shadow-md max-w-2xl mx-auto">
          <div className="flex items-center justify-center mb-2">
            <Megaphone size={20} className="mr-2 text-accent" />
            <span className="font-semibold text-accent text-sm">Admin Announcement</span>
          </div>
          <p className="text-sm text-foreground text-left">{text}</p>
          {timestamp && (
            <p className="text-xs text-muted-foreground mt-2 text-right">{formattedTime}</p>
          )}
        </div>
      </div>
    );
  }

  const renderMedia = () => {
    if (type === 'image' && mediaUrl) {
      return (
        <div className="mt-2 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg">
          {/* Using regular img tag for Data URI. Next/Image is better for external URLs. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={mediaUrl}
            alt={fileName || 'Sent image'}
            className="rounded-lg object-contain max-h-64 w-auto shadow-md"
          />
          {fileName && <p className="text-xs mt-1 opacity-70 truncate">{fileName}</p>}
        </div>
      );
    }
    if (type === 'video' && mediaUrl) {
      return (
        <div className="mt-2">
          <video
            src={mediaUrl}
            controls
            className="rounded-lg max-h-72 w-auto shadow-md"
          />
          {fileName && <p className="text-xs mt-1 opacity-70 truncate">{fileName}</p>}
        </div>
      );
    }
    return null;
  };

  const isUserMessage = type === 'user' || type === 'image' || type === 'video';
  // A message is reportable if it's a user message and not sent by the current user viewing it.
  const isReportable = isUserMessage && messageSenderSocketId !== currentUserSocketId;


  return (
    <div
      className={cn(
        'flex items-end gap-2 my-3 group relative',
        isSender ? 'flex-row-reverse' : 'flex-row'
      )}
    >
      {!isSender && (
         <Avatar className="h-8 w-8 shadow-sm self-start">
            <AvatarFallback className="bg-primary/20 text-primary text-xs">
                {userName === 'AI Assistant' ? <Bot size={16}/> : getInitials(userName)}
            </AvatarFallback>
         </Avatar>
      )}
      <div
        className={cn(
          'max-w-[70%] p-3 rounded-xl shadow-md break-words',
          isSender
            ? 'bg-primary text-primary-foreground rounded-br-none'
            : 'bg-card text-card-foreground rounded-bl-none border'
        )}
      >
        <div className="flex justify-between items-start">
          <div>
            {!isSender && (
              <p className="text-xs font-semibold mb-1 text-primary">
                {userName}
              </p>
            )}
            {text && <p className="text-sm">{text}</p>}
            {renderMedia()}
          </div>

          {isReportable && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity ml-2 shrink-0"
                >
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">Message options</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={isSender ? "end" : "start"}>
                <DropdownMenuItem onClick={handleReportMessage}>
                  <AlertTriangle className="mr-2 h-4 w-4 text-orange-500" />
                  Report Message
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        <p
          className={cn(
            'text-xs mt-1',
            isSender ? 'text-primary-foreground/70 text-right' : 'text-muted-foreground text-left'
          )}
        >
          {formattedTime}
        </p>
      </div>
       {isSender && (
         <Avatar className="h-8 w-8 shadow-sm self-start">
            <AvatarFallback className="bg-accent/80 text-accent-foreground text-xs">
                {getInitials(userName)}
            </AvatarFallback>
         </Avatar>
      )}
    </div>
  );
}
