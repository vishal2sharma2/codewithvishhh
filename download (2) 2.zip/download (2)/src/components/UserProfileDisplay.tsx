
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UserCircle } from 'lucide-react';
import Link from 'next/link';

const NAME_KEY = 'chatterboxDisplayName';
const AGE_KEY = 'chatterboxUserAge';
const CITY_KEY = 'chatterboxUserCity';

export default function UserProfileDisplay() {
  const [name, setName] = useState<string | null>(null);
  const [age, setAge] = useState<string | null>(null);
  const [city, setCity] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const loadProfile = () => {
      const savedName = localStorage.getItem(NAME_KEY);
      const savedAge = localStorage.getItem(AGE_KEY);
      const savedCity = localStorage.getItem(CITY_KEY);

      setName(savedName);
      setAge(savedAge);
      setCity(savedCity);
      setIsLoaded(true);
    };
    
    loadProfile();

    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === NAME_KEY || event.key === AGE_KEY || event.key === CITY_KEY) {
        loadProfile();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  if (!isLoaded) {
    // Optional: Show a minimal loading state or nothing until loaded
    return (
      <Card className="w-full max-w-md mb-8 shadow-lg animate-pulse">
        <CardHeader>
          <CardTitle className="text-xl text-primary flex items-center">
            <UserCircle className="mr-2 h-6 w-6" /> Your Info
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </CardContent>
      </Card>
    );
  }

  // Check if all details are filled
  const allDetailsFilled = name && age && city;

  if (allDetailsFilled) {
    return null; // Hide the component if all details are present
  }

  // If not all details are filled, show the card
  const hasSomeProfileData = name || age || city;

  return (
    <Card className="w-full max-w-md mb-8 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-primary flex items-center">
          <UserCircle className="mr-2 h-6 w-6" /> Your Info
        </CardTitle>
        <CardDescription>This information is saved in your browser. Complete your profile for a better experience.</CardDescription>
      </CardHeader>
      <CardContent>
        {hasSomeProfileData ? (
          <div className="space-y-2">
            <p><strong>Name:</strong> {name || <span className="text-muted-foreground italic">Not set</span>}</p>
            <p><strong>Age:</strong> {age || <span className="text-muted-foreground italic">Not set</span>}</p>
            <p><strong>City:</strong> {city || <span className="text-muted-foreground italic">Not set</span>}</p>
            {!allDetailsFilled && (
              <p className="mt-3">
                <Link href="/profile" className="text-sm text-primary hover:underline">
                  Complete your profile...
                </Link>
              </p>
            )}
          </div>
        ) : (
          <p className="text-muted-foreground">
            You haven't set your profile information yet. 
            <Link href="/profile" className="text-primary hover:underline ml-1">
              Set it up now!
            </Link>
          </p>
        )}
      </CardContent>
    </Card>
  );
}
