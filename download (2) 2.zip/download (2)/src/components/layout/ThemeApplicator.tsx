
'use client';

import { useEffect } from 'react';
import { themes, DEFAULT_THEME_NAME, type ThemeColors } from '@/lib/themes';

function applyThemeVariables(themeColors: ThemeColors | undefined) {
  if (!themeColors) return;
  for (const [variable, value] of Object.entries(themeColors)) {
    document.documentElement.style.setProperty(variable, value);
  }
}

export default function ThemeApplicator() {
  useEffect(() => {
    const savedThemeName = localStorage.getItem('adminAppliedThemeName');
    if (savedThemeName && themes[savedThemeName]) {
      applyThemeVariables(themes[savedThemeName]);
    } else {
      // Apply default theme if no theme is saved or saved theme is invalid
      applyThemeVariables(themes[DEFAULT_THEME_NAME]);
    }
  }, []);

  return null; // This component does not render anything visible
}
