
import Link from 'next/link';
import { Heart } from 'lucide-react';

interface AppFooterProps {
  footerText: string;
}

export default function AppFooter({ footerText }: AppFooterProps) {
  const currentYear = new Date().getFullYear();
  const processedFooterText = footerText 
    ? footerText.replace(/\$\{new Date\(\)\.getFullYear\(\)\}/g, currentYear.toString())
    : `© ${currentYear} ChatterBox Rooms. All rights reserved.`;

  return (
    <footer className="bg-muted text-muted-foreground py-6 mt-auto">
      <div className="container mx-auto px-4 sm:px-6 md:px-8 text-center text-sm">
        <p className="mb-2">{processedFooterText}</p>
        <div className="flex flex-wrap justify-center items-center space-x-4">
          <Link href="/terms-and-conditions" className="hover:text-primary transition-colors">
            Terms & Conditions
          </Link>
          <span>|</span>
          <Link href="/privacy-policy" className="hover:text-primary transition-colors">
            Privacy Policy
          </Link>
          <span>|</span>
          <Link 
            href="https://example.com/donate" // Replace with your actual donation link
            target="_blank" 
            rel="noopener noreferrer" 
            className="flex items-center hover:text-primary transition-colors"
          >
            <Heart className="mr-1 h-4 w-4 text-destructive" />
            Support Us
          </Link>
        </div>
      </div>
    </footer>
  );
}
