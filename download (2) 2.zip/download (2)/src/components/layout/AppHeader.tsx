
import Link from 'next/link';
import { MessagesSquare, Info, Mail, UserCircle, Instagram, Linkedin, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AppHeaderProps {
  websiteName: string;
  instagramUrl?: string;
  linkedinUrl?: string;
  youtubeUrl?: string;
}

export default function AppHeader({ websiteName, instagramUrl, linkedinUrl, youtubeUrl }: AppHeaderProps) {
  return (
    <header className="bg-primary text-primary-foreground shadow-md">
      <div className="container mx-auto px-4 sm:px-6 md:px-8 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-2xl font-bold">
          <MessagesSquare size={28} />
          <span>{websiteName || 'ChatterBox Rooms'}</span>
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          {/* Standard Links */}
          <Button variant="ghost" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground px-2 sm:px-3">
            <Link href="/#features"> {/* Assuming features section is on homepage with id="features" */}
              <Info className="mr-1 sm:mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Features</span>
            </Link>
          </Button>
          <Button variant="ghost" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground px-2 sm:px-3">
            <Link href="/#contact"> {/* Assuming contact section is on homepage with id="contact" */}
              <Mail className="mr-1 sm:mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Contact</span>
            </Link>
          </Button>
          <Button variant="ghost" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground px-2 sm:px-3">
            <Link href="/profile">
              <UserCircle className="mr-1 sm:mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Profile</span>
            </Link>
          </Button>

          {/* Social Media Icons */}
          {instagramUrl && (
            <Button variant="ghost" size="icon" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground">
              <Link href={instagramUrl} target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </Link>
            </Button>
          )}
          {linkedinUrl && (
            <Button variant="ghost" size="icon" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground">
              <Link href={linkedinUrl} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </Link>
            </Button>
          )}
          {youtubeUrl && (
            <Button variant="ghost" size="icon" asChild className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground">
              <Link href={youtubeUrl} target="_blank" rel="noopener noreferrer" aria-label="YouTube">
                <Youtube className="h-5 w-5" />
              </Link>
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}

    