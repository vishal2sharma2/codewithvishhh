
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { generateReadableRoomName } from '@/lib/roomUtils';
import { Zap, MessageCirclePlus, Lock, Clock, ShieldCheck, Users } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { RetentionPolicy, RoomMode } from '@/types';
import { useToast } from '@/hooks/use-toast';

const DEFAULT_MAX_USERS = 10;
const MIN_MAX_USERS = 1;
const MAX_MAX_USERS = 1000;


export default function RoomSelectionForm() {
  const [roomName, setRoomName] = useState('');
  const [password, setPassword] = useState('');
  const [retentionPolicy, setRetentionPolicy] = useState<RetentionPolicy>('none');
  const [maxUsersInput, setMaxUsersInput] = useState<string>(DEFAULT_MAX_USERS.toString());
  const router = useRouter();
  const { toast } = useToast();

  const handleRoomAction = (mode: RoomMode) => {
    const targetRoom = roomName.trim();
    if (!targetRoom) {
      toast({
        title: 'Error',
        description: 'Room name cannot be empty.',
        variant: 'destructive',
      });
      return;
    }

    let maxUsers = parseInt(maxUsersInput, 10);
    if (isNaN(maxUsers) || maxUsers < MIN_MAX_USERS || maxUsers > MAX_MAX_USERS) {
      toast({
        title: 'Invalid Max Users',
        description: `Max users must be a number between ${MIN_MAX_USERS} and ${MAX_MAX_USERS}. Defaulting to ${DEFAULT_MAX_USERS}.`,
        variant: 'destructive',
      });
      maxUsers = DEFAULT_MAX_USERS; // Default if invalid
      setMaxUsersInput(DEFAULT_MAX_USERS.toString());
    }


    let url = `/room/${encodeURIComponent(targetRoom)}`;
    const queryParams = new URLSearchParams();

    if (password.trim()) {
      queryParams.append('password', encodeURIComponent(password.trim()));
    }
    if (retentionPolicy !== 'none') {
      queryParams.append('retention', retentionPolicy);
    }
    queryParams.append('mode', mode);
    queryParams.append('maxUsers', maxUsers.toString());


    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
    router.push(url);
  };
  
  const handleGenerateRoom = () => {
    const newRoomName = generateReadableRoomName();
    let url = `/room/${encodeURIComponent(newRoomName)}`;
    const queryParams = new URLSearchParams();

    if (password.trim()) {
      queryParams.append('password', encodeURIComponent(password.trim()));
    }
    if (retentionPolicy !== 'none') {
      queryParams.append('retention', retentionPolicy);
    }
    
    let maxUsers = parseInt(maxUsersInput, 10);
    if (isNaN(maxUsers) || maxUsers < MIN_MAX_USERS || maxUsers > MAX_MAX_USERS) {
      maxUsers = DEFAULT_MAX_USERS; 
    }
    queryParams.append('maxUsers', maxUsers.toString());
    queryParams.append('mode', 'public'); // Generated rooms are public by default

    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
    router.push(url);
  };

  return (
    <Card className="w-full max-w-md shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl text-primary">Join or Create a Room</CardTitle>
        <CardDescription>Enter room details. Your display name will be set when you join.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="roomName">Room Name</Label>
          <Input
            id="roomName"
            type="text"
            placeholder="Enter room name (e.g., 'study-group')"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            className="text-base"
            aria-label="Room Name"
          />
        </div>
        <div>
          <Label htmlFor="password">Password (Optional)</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="password"
              type="password"
              placeholder="Leave blank for no password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="text-base pl-10"
              aria-label="Room Password"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="retentionPolicy">Message Retention</Label>
          <div className="relative">
            <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Select value={retentionPolicy} onValueChange={(value) => setRetentionPolicy(value as RetentionPolicy)}>
              <SelectTrigger className="w-full pl-10" id="retentionPolicy" aria-label="Message Retention Policy">
                <SelectValue placeholder="Select retention period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Permanent (None)</SelectItem>
                <SelectItem value="24h">24 Hours</SelectItem>
                <SelectItem value="48h">48 Hours</SelectItem>
                <SelectItem value="3d">3 Days</SelectItem>
                <SelectItem value="7d">7 Days</SelectItem>
                <SelectItem value="30d">30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label htmlFor="maxUsers">Max Users ({MIN_MAX_USERS}-{MAX_MAX_USERS})</Label>
          <div className="relative">
            <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="maxUsers"
              type="number"
              placeholder={`Default: ${DEFAULT_MAX_USERS}`}
              value={maxUsersInput}
              onChange={(e) => setMaxUsersInput(e.target.value)}
              min={MIN_MAX_USERS.toString()}
              max={MAX_MAX_USERS.toString()}
              className="text-base pl-10"
              aria-label="Max Users"
            />
          </div>
        </div>
        
        <Button 
          type="button" 
          onClick={() => handleRoomAction('public')} 
          className="w-full" 
          disabled={!roomName.trim()}
        >
          <MessageCirclePlus className="mr-2 h-5 w-5" />
          Join/Create Public Room
        </Button>

        <Button 
          type="button" 
          onClick={() => handleRoomAction('personal')} 
          className="w-full mt-2" 
          variant="outline"
          disabled={!roomName.trim()}
        >
          <ShieldCheck className="mr-2 h-5 w-5" />
          Join/Create Personal Room
        </Button>
        {!password.trim() && (
          <p className="text-xs text-muted-foreground mt-1 text-center">
            For Personal Rooms, consider adding a password for enhanced privacy.
          </p>
        )}

      </CardContent>
      <CardFooter className="flex flex-col items-center">
        <div className="relative my-4 w-full">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">
              Or
            </span>
          </div>
        </div>
        <Button variant="outline" onClick={handleGenerateRoom} className="w-full">
          <Zap className="mr-2 h-5 w-5 text-accent" />
          Generate & Join Random Room
        </Button>
      </CardFooter>
    </Card>
  );
}
