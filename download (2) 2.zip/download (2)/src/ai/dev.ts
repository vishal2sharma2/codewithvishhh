import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-replies.ts';